import { Router, type IRouter } from "express";
import healthRouter from "./health";
import openaiRouter from "./openai";
import mobileRouter from "./mobile";

const router: IRouter = Router();

router.use(healthRouter);
router.use(openaiRouter);
router.use("/mobile", mobileRouter);

export default router;
