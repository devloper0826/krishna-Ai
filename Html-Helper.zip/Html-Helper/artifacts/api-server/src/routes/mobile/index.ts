import { Router } from "express";
import OpenAI from "openai";

const router = Router();

function createOpenAIClient() {
  const apiKey = process.env.OPENAI_API_KEY;
  const isOpenRouter = apiKey?.startsWith("sk-or-");
  return new OpenAI({
    apiKey,
    ...(isOpenRouter ? { baseURL: "https://openrouter.ai/api/v1" } : {}),
  });
}

const isOpenRouter = process.env.OPENAI_API_KEY?.startsWith("sk-or-");

const OPENROUTER_MODEL_MAP: Record<string, string> = {
  "gpt-4o-mini": "openai/gpt-4o-mini",
  "gpt-4o": "openai/gpt-4o",
  "gpt-3.5-turbo": "openai/gpt-3.5-turbo",
};

// POST /api/mobile/chat — streaming chat (no Clerk auth, for mobile app)
router.post("/chat", async (req, res) => {
  const {
    messages = [],
    model: rawModel = "gpt-4o-mini",
    temperature = 0.7,
    systemPrompt,
  } = req.body as {
    messages: { role: "user" | "assistant"; content: string }[];
    model?: string;
    temperature?: number;
    systemPrompt?: string;
  };

  const model = isOpenRouter
    ? (OPENROUTER_MODEL_MAP[rawModel] ?? "openai/gpt-4o-mini")
    : rawModel;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  try {
    const openai = createOpenAIClient();
    const systemMessages: OpenAI.ChatCompletionSystemMessageParam[] = systemPrompt
      ? [{ role: "system", content: systemPrompt }]
      : [];

    const stream = await openai.chat.completions.create({
      model,
      messages: [...systemMessages, ...messages],
      temperature,
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write("data: [DONE]\n\n");
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.write(`data: ${JSON.stringify({ error: msg })}\n\n`);
  }

  res.end();
});

// POST /api/mobile/generate-image — image generation (no auth)
// Uses Pollinations.ai (free, no key) for OpenRouter keys,
// falls back to gpt-image-1 for direct OpenAI keys.
router.post("/generate-image", async (req, res) => {
  const { prompt } = req.body as { prompt: string };

  if (!prompt) {
    return void res.status(400).json({ error: "prompt is required" });
  }

  try {
    let url: string;

    if (isOpenRouter) {
      // Pollinations.ai — free, no API key required, powered by FLUX
      const seed = Math.floor(Math.random() * 999999);
      url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=flux&nologo=true&seed=${seed}`;
    } else {
      const openai = createOpenAIClient();
      const response = await openai.images.generate({
        model: "gpt-image-1",
        prompt,
        n: 1,
        size: "1024x1024",
        quality: "auto",
      });
      const imgUrl = response.data[0]?.url;
      if (!imgUrl) throw new Error("No image URL returned");
      url = imgUrl;
    }

    res.json({ url });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Image generation failed";
    res.status(400).json({ error: msg });
  }
});

export default router;
