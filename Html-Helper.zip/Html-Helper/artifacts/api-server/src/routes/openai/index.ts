import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import OpenAI from "openai";
import { eq, asc, and } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { db, conversations as conversationsTable, messages as messagesTable } from "@workspace/db";
import {
  SendOpenaiMessageBody,
  SendOpenaiMessageParams,
  GetOpenaiConversationParams,
  DeleteOpenaiConversationParams,
  ListOpenaiMessagesParams,
  CreateOpenaiConversationBody,
  UpdateOpenaiConversationParams,
  UpdateOpenaiConversationBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY must be set.");
}

const apiKey = process.env.OPENAI_API_KEY ?? "";
const isOpenRouter = apiKey.startsWith("sk-or-");
const openai = new OpenAI({
  apiKey,
  ...(isOpenRouter ? { baseURL: "https://openrouter.ai/api/v1" } : {}),
});

// Auth middleware — requires a valid Clerk session
function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const auth = getAuth(req);
  const userId = (auth as { userId?: string | null })?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as Request & { userId: string }).userId = userId;
  next();
}

router.get("/openai/conversations", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const conversations = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.userId, userId))
    .orderBy(conversationsTable.createdAt);
  res.json(conversations);
});

router.post("/openai/conversations", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const parsed = CreateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [conversation] = await db
    .insert(conversationsTable)
    .values({ userId, title: parsed.data.title })
    .returning();
  res.status(201).json(conversation);
});

router.get("/openai/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const params = GetOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, params.data.id), eq(conversationsTable.userId, userId)));
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, params.data.id))
    .orderBy(asc(messagesTable.createdAt));
  res.json({ ...conversation, messages });
});

router.patch("/openai/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const params = UpdateOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateOpenaiConversationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [updated] = await db
    .update(conversationsTable)
    .set({ title: body.data.title })
    .where(and(eq(conversationsTable.id, params.data.id), eq(conversationsTable.userId, userId)))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  res.json(updated);
});

/**
 * Generate image — uses Pollinations.ai (free, no key) for OpenRouter keys
 * and OpenAI gpt-image-1 for direct OpenAI keys.
 */
router.post("/openai/conversations/:id/generate-image", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const id = parseInt(req.params.id ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const prompt = typeof req.body.prompt === "string" ? req.body.prompt.trim() : "";
  if (!prompt) { res.status(400).json({ error: "prompt is required" }); return; }

  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, userId)));
  if (!conversation) { res.status(404).json({ error: "Conversation not found" }); return; }

  // Save user message
  await db.insert(messagesTable).values({ conversationId: id, role: "user", content: `🎨 Generate image: ${prompt}` });

  try {
    let url: string;

    if (isOpenRouter) {
      // OpenRouter doesn't support DALL-E; use Pollinations.ai (free, no key needed)
      const seed = Math.floor(Math.random() * 999999);
      url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=flux&nologo=true&seed=${seed}`;
    } else {
      // Direct OpenAI key — use gpt-image-1
      const result = await openai.images.generate({
        model: "gpt-image-1",
        prompt,
        n: 1,
        size: "1024x1024",
        quality: "auto",
      } as Parameters<typeof openai.images.generate>[0]);
      const imgUrl = result.data?.[0]?.url;
      if (!imgUrl) throw new Error("No image URL returned");
      url = imgUrl;
    }

    const imageJson = JSON.stringify({ type: "image", url, prompt });
    await db.insert(messagesTable).values({ conversationId: id, role: "assistant", content: imageJson });
    res.json({ url, prompt });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Image generation failed";
    await db.insert(messagesTable).values({ conversationId: id, role: "assistant", content: `Sorry, I couldn't generate the image: ${msg}` });
    res.status(500).json({ error: msg });
  }
});

router.post("/openai/conversations/:id/generate-title", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const id = parseInt(req.params.id ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const msgs = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, id))
    .orderBy(asc(messagesTable.createdAt));

  const firstUser = msgs.find((m) => m.role === "user");
  if (!firstUser) { res.status(200).json({ title: "New Chat" }); return; }

  try {
    const completion = await openai.chat.completions.create({
      model: isOpenRouter ? "openai/gpt-4o-mini" : "gpt-4o-mini",
      max_tokens: 20,
      messages: [
        { role: "system", content: "Generate a short conversation title (max 5 words, no punctuation, no quotes) from the user's first message. Only output the title." },
        { role: "user", content: firstUser.content.slice(0, 300) },
      ],
    });
    const title = completion.choices[0]?.message?.content?.trim() ?? "New Chat";
    await db.update(conversationsTable)
      .set({ title })
      .where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, userId)));
    res.json({ title });
  } catch {
    res.status(200).json({ title: "New Chat" });
  }
});

router.delete("/openai/conversations", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const userConvs = await db
    .select({ id: conversationsTable.id })
    .from(conversationsTable)
    .where(eq(conversationsTable.userId, userId));
  for (const conv of userConvs) {
    await db.delete(messagesTable).where(eq(messagesTable.conversationId, conv.id));
  }
  await db.delete(conversationsTable).where(eq(conversationsTable.userId, userId));
  res.sendStatus(204);
});

router.delete("/openai/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const params = DeleteOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(conversationsTable)
    .where(and(eq(conversationsTable.id, params.data.id), eq(conversationsTable.userId, userId)))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/openai/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const params = ListOpenaiMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [conv] = await db
    .select({ id: conversationsTable.id })
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, params.data.id), eq(conversationsTable.userId, userId)));
  if (!conv) { res.status(404).json({ error: "Not found" }); return; }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, params.data.id))
    .orderBy(asc(messagesTable.createdAt));
  res.json(messages);
});

router.post("/openai/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as Request & { userId: string }).userId;
  const params = SendOpenaiMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = SendOpenaiMessageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const conversationId = params.data.id;
  const userContent = body.data.content;
  const language = typeof req.body.language === "string" ? req.body.language : "English";
  const ALLOWED_MODELS = ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"];
  const OPENROUTER_MODELS: Record<string, string> = {
    "gpt-4o-mini": "openai/gpt-4o-mini",
    "gpt-4o": "openai/gpt-4o",
    "gpt-3.5-turbo": "openai/gpt-3.5-turbo",
  };
  const rawModel = ALLOWED_MODELS.includes(req.body.model) ? req.body.model : "gpt-4o-mini";
  const model = isOpenRouter ? (OPENROUTER_MODELS[rawModel] ?? "openai/gpt-4o-mini") : rawModel;
  const rawTemp = parseFloat(req.body.temperature);
  const temperature = !isNaN(rawTemp) && rawTemp >= 0 && rawTemp <= 2 ? rawTemp : 0.7;
  const customInstructions = typeof req.body.systemPrompt === "string" ? req.body.systemPrompt.trim() : "";

  const languagePrompts: Record<string, string> = {
    English: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in clear, fluent English.",
    Hindi: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Hindi using Devanagari script (हिंदी).",
    Hinglish: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Hinglish — a natural, casual mix of Hindi and English written in Roman script, exactly the way young Indians talk in everyday conversation. Example: 'Yaar, ye problem solve karna easy hai, bas ye steps follow karo.'",
    Spanish: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in fluent Spanish.",
    French: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in fluent French.",
    Arabic: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in fluent Arabic.",
    Bengali: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Bengali (বাংলা).",
    Tamil: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Tamil (தமிழ்).",
    Telugu: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Telugu (తెలుగు).",
    Gujarati: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Gujarati (ગુજરાતી).",
    Marathi: "You are KrishnaAI, a highly capable and helpful AI assistant. Always respond in Marathi (मराठी).",
  };

  const baseSystemPrompt = languagePrompts[language] ?? languagePrompts["English"]!;
  const systemPrompt = customInstructions
    ? `${baseSystemPrompt}\n\nAdditional instructions from the user: ${customInstructions}`
    : baseSystemPrompt;

  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, conversationId), eq(conversationsTable.userId, userId)));
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  await db.insert(messagesTable).values({
    conversationId,
    role: "user",
    content: userContent,
  });

  const history = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, conversationId))
    .orderBy(asc(messagesTable.createdAt));

  const chatMessages: Array<{ role: "user" | "assistant" | "system"; content: string }> = [
    { role: "system", content: systemPrompt },
    ...history.map((m) => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.content,
    })),
  ];

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";
  const stream = await openai.chat.completions.create({
    model,
    max_tokens: 8192,
    temperature,
    messages: chatMessages,
    stream: true,
  });

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content;
    if (content) {
      fullResponse += content;
      res.write(`data: ${JSON.stringify({ content })}\n\n`);
    }
  }

  await db.insert(messagesTable).values({
    conversationId,
    role: "assistant",
    content: fullResponse,
  });

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

export default router;
