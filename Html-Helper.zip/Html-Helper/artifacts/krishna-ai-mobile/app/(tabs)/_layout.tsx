import { Slot } from 'expo-router';

// Chat app — no tab bar needed. Slot renders the active child screen.
export default function TabLayout() {
  return <Slot />;
}
