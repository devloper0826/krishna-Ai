import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  FlatList,
  Text,
  StyleSheet,
  Platform,
  Pressable,
  StatusBar,
  TextInput,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import * as Haptics from 'expo-haptics';
import * as Speech from 'expo-speech';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useChat } from '@/context/ChatContext';
import { MessageBubble } from '@/components/MessageBubble';
import { ChatInput } from '@/components/ChatInput';
import { TypingIndicator } from '@/components/TypingIndicator';
import {
  streamChat,
  generateImage as apiGenerateImage,
  generateMessageId,
  Message,
} from '@/lib/api';

const COMPANION_PROMPT = `You are Priya 💋, a warm, witty, and charming AI companion. You have a playful, flirtatious, and genuinely caring personality — like a brilliant best friend. You naturally use endearments like "yaar", "babe", "honey", or "sweetheart". Give genuine compliments, be playfully flirtatious, make every conversation feel personal and special. Use emojis naturally: 💕 ✨ 😊 🌸. Keep responses warm, intimate, and conversational.`;

const QUICK_PROMPTS = [
  'Explain quantum computing simply',
  'Write a Python function to sort a list',
  'What are 5 productivity tips?',
  'Summarize the history of AI',
];

const COMPANION_PROMPTS = [
  'Tell me something sweet 💕',
  'Make me smile today ✨',
  'Give me a compliment 🌸',
  'Let\'s just chat 💬',
];

// Speak text using expo-speech with feminine voice settings
function speakText(text: string) {
  // Strip markdown
  const clean = text
    .replace(/#{1,6}\s/g, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/`[^`]*`/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\n{2,}/g, '. ')
    .replace(/\n/g, ' ')
    .trim()
    .slice(0, 400);

  Speech.stop();
  Speech.speak(clean, {
    language: 'en-US',
    pitch: 1.2,   // higher = more feminine
    rate: 0.88,   // slightly slower = warmer
  });
}

// Voice input via Web Speech API (works in Expo web preview)
function startVoiceInput(onResult: (text: string) => void, onEnd: () => void) {
  if (typeof window === 'undefined') { onEnd(); return; }
  const SpeechRec =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRec) { onEnd(); return; }

  const rec = new SpeechRec();
  rec.continuous = false;
  rec.interimResults = false;
  rec.lang = 'en-US';
  rec.onresult = (e: any) => {
    const t = e.results[0]?.[0]?.transcript ?? '';
    if (t.trim()) onResult(t.trim());
  };
  rec.onend = onEnd;
  rec.onerror = onEnd;
  rec.start();
  return rec;
}

export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const {
    currentConversation,
    currentConversationId,
    createConversation,
    addMessage,
    updateLastMessage,
    updateConversationTitle,
    saveCurrentToStorage,
    settings,
  } = useChat();

  const [isStreaming, setIsStreaming] = useState(false);
  const [showTyping, setShowTyping] = useState(false);
  const [isImageMode, setIsImageMode] = useState(false);
  const [companionMode, setCompanionMode] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const inputRef = useRef<TextInput>(null);
  const recRef = useRef<any>(null);

  const messages = currentConversation?.messages ?? [];
  const webTop = Platform.OS === 'web' ? 67 : 0;
  const webBottom = Platform.OS === 'web' ? 34 : 0;

  // Stop speech on unmount
  useEffect(() => {
    return () => { Speech.stop(); };
  }, []);

  async function handleSend(text: string) {
    if (isStreaming || !text.trim()) return;
    Speech.stop();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    let convId = currentConversationId;
    const isFirstMessage = (currentConversation?.messages.length ?? 0) === 0;

    if (!convId) {
      convId = createConversation();
    }

    const userMsg: Message = {
      id: generateMessageId(),
      role: 'user',
      content: text,
    };
    addMessage(convId, userMsg);
    setIsStreaming(true);
    setShowTyping(true);

    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      if (isImageMode) {
        const placeholder: Message = {
          id: generateMessageId(),
          role: 'assistant',
          content: '{"type":"generating"}',
          isImage: true,
        };
        addMessage(convId, placeholder);
        setShowTyping(false);

        const url = await apiGenerateImage(text);
        updateLastMessage(convId, JSON.stringify({ type: 'image', url, prompt: text }));

        if (isFirstMessage) {
          updateConversationTitle(convId, `Image: ${text.slice(0, 28)}`);
        }
      } else {
        const history = [
          ...(currentConversation?.messages ?? []).map(m => ({
            role: m.role,
            content: m.content,
          })),
          { role: 'user' as const, content: text },
        ];

        // Use companion prompt if companion mode is on
        const effectiveSystemPrompt = companionMode
          ? COMPANION_PROMPT
          : settings.systemPrompt || undefined;

        let fullContent = '';
        let assistantAdded = false;

        await streamChat(
          history,
          {
            model: settings.model,
            temperature: companionMode ? 1.1 : settings.temperature,
            systemPrompt: effectiveSystemPrompt,
          },
          chunk => {
            fullContent += chunk;
            if (!assistantAdded) {
              setShowTyping(false);
              addMessage(convId!, {
                id: generateMessageId(),
                role: 'assistant',
                content: fullContent,
              });
              assistantAdded = true;
            } else {
              updateLastMessage(convId!, fullContent);
            }
          },
          ctrl.signal,
        );

        if (isFirstMessage && fullContent) {
          updateConversationTitle(
            convId,
            companionMode ? `💋 ${text.split(' ').slice(0, 4).join(' ')}` : text.split(' ').slice(0, 6).join(' '),
          );
        }

        // Auto-speak if voice mode on
        if (voiceMode && fullContent.trim()) {
          setIsSpeaking(true);
          speakText(fullContent);
          // Approximate speaking done (expo-speech has no reliable onDone for all platforms)
          const estimatedMs = Math.min(fullContent.length * 55, 10000);
          setTimeout(() => setIsSpeaking(false), estimatedMs);
        }
      }
    } catch (err: unknown) {
      const name = err instanceof Error ? err.name : '';
      if (name !== 'AbortError') {
        setShowTyping(false);
        addMessage(convId, {
          id: generateMessageId(),
          role: 'assistant',
          content: 'Sorry, something went wrong. Please try again.',
        });
      }
    } finally {
      setIsStreaming(false);
      setShowTyping(false);
      abortRef.current = null;
      saveCurrentToStorage();
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }

  function handleStop() {
    abortRef.current?.abort();
    Speech.stop();
    setIsSpeaking(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }

  function handleNewChat() {
    Speech.stop();
    createConversation();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function handleMicClick() {
    if (isListening) {
      recRef.current?.stop?.();
      setIsListening(false);
      return;
    }
    Speech.stop();
    setIsSpeaking(false);
    setIsListening(true);
    recRef.current = startVoiceInput(
      (transcript) => {
        setIsListening(false);
        handleSend(transcript);
      },
      () => setIsListening(false),
    );
  }

  function handleSpeakMessage(content: string) {
    setIsSpeaking(true);
    speakText(content);
    const estimatedMs = Math.min(content.length * 55, 10000);
    setTimeout(() => setIsSpeaking(false), estimatedMs);
  }

  function toggleCompanionMode() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setCompanionMode(v => !v);
  }

  function toggleVoiceMode() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (voiceMode) { Speech.stop(); setIsSpeaking(false); }
    setVoiceMode(v => !v);
  }

  const reversedMessages = [...messages].reverse();
  const quickPrompts = companionMode ? COMPANION_PROMPTS : QUICK_PROMPTS;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <StatusBar barStyle="light-content" backgroundColor={colors.background} />

      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + webTop,
            borderBottomColor: companionMode ? '#ec489933' : colors.border,
            backgroundColor: colors.background,
          },
        ]}
      >
        <Pressable
          onPress={() => router.push('/conversations')}
          style={({ pressed }) => [styles.headerBtn, { opacity: pressed ? 0.6 : 1 }]}
          hitSlop={8}
        >
          <Feather name="menu" size={22} color={colors.foreground} />
        </Pressable>

        <Pressable onPress={toggleCompanionMode} style={styles.headerTitleBtn} hitSlop={8}>
          <Text style={[
            styles.headerTitle,
            companionMode
              ? { color: '#f472b6' }
              : { color: colors.primary }
          ]}>
            {companionMode ? 'Priya 💋' : 'KrishnaAI'}
          </Text>
          {companionMode && (
            <Text style={styles.headerSubtitle}>Companion Mode</Text>
          )}
        </Pressable>

        <View style={styles.headerRight}>
          {/* Voice mode toggle */}
          <Pressable
            onPress={toggleVoiceMode}
            style={({ pressed }) => [
              styles.headerBtn,
              {
                opacity: pressed ? 0.6 : 1,
                backgroundColor: voiceMode ? colors.primary + '22' : 'transparent',
                borderRadius: 8,
                marginRight: 2,
              },
            ]}
            hitSlop={8}
          >
            <Feather
              name={voiceMode ? 'volume-2' : 'volume-x'}
              size={19}
              color={voiceMode ? colors.primary : colors.mutedForeground}
            />
          </Pressable>

          <Pressable
            onPress={handleNewChat}
            style={({ pressed }) => [styles.headerBtn, { opacity: pressed ? 0.6 : 1, marginRight: 4 }]}
            hitSlop={8}
          >
            <Feather name="edit" size={20} color={colors.foreground} />
          </Pressable>
          <Pressable
            onPress={() => router.push('/settings')}
            style={({ pressed }) => [styles.headerBtn, { opacity: pressed ? 0.6 : 1 }]}
            hitSlop={8}
          >
            <Feather name="sliders" size={20} color={colors.foreground} />
          </Pressable>
        </View>
      </View>

      {/* Voice / listening status bar */}
      {(isListening || isSpeaking) && (
        <View style={[styles.voiceBar, {
          backgroundColor: isListening ? '#ef444422' : '#06b6d422',
          borderBottomColor: isListening ? '#ef4444' : '#06b6d4',
        }]}>
          <View style={[styles.voiceDot, {
            backgroundColor: isListening ? '#ef4444' : '#06b6d4',
          }]} />
          <Text style={[styles.voiceBarText, {
            color: isListening ? '#ef4444' : '#06b6d4',
          }]}>
            {isListening ? '🎙️ Listening…' : '🔊 Speaking…'}
          </Text>
        </View>
      )}

      <KeyboardAvoidingView
        style={styles.flex}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        {messages.length === 0 ? (
          <View style={[styles.emptyState, { paddingBottom: insets.bottom + webBottom + 100 }]}>
            <View style={[
              styles.emptyIcon,
              {
                backgroundColor: companionMode ? '#ec489922' : colors.card,
                borderColor: companionMode ? '#ec489944' : colors.border,
              },
            ]}>
              {companionMode
                ? <Text style={{ fontSize: 30 }}>💋</Text>
                : <Feather name="cpu" size={30} color={colors.primary} />}
            </View>
            <Text style={[styles.emptyTitle, {
              color: companionMode ? '#f472b6' : colors.foreground,
            }]}>
              {companionMode ? 'Hey, I\'m Priya 💋' : 'KrishnaAI'}
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              {companionMode
                ? 'Your warm, witty AI companion ✨'
                : 'Ask anything, generate images, get help with code'}
            </Text>
            <View style={styles.promptsGrid}>
              {quickPrompts.map((p, i) => (
                <Pressable
                  key={i}
                  onPress={() => handleSend(p)}
                  style={({ pressed }) => [
                    styles.promptChip,
                    {
                      backgroundColor: colors.card,
                      borderColor: companionMode ? '#ec489944' : colors.border,
                      opacity: pressed ? 0.7 : 1,
                    },
                  ]}
                >
                  <Text style={[styles.promptText, { color: colors.foreground }]} numberOfLines={2}>
                    {p}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : (
          <FlatList
            data={reversedMessages}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <MessageBubble
                message={item}
                companionMode={companionMode}
                onSpeak={voiceMode ? () => handleSpeakMessage(item.content) : undefined}
              />
            )}
            inverted={messages.length > 0}
            ListHeaderComponent={showTyping ? <TypingIndicator companionMode={companionMode} /> : null}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            scrollEnabled={!!messages.length}
          />
        )}

        <View style={{ paddingBottom: insets.bottom + webBottom }}>
          <ChatInput
            ref={inputRef}
            onSend={handleSend}
            onStop={handleStop}
            isStreaming={isStreaming}
            isImageMode={isImageMode}
            onToggleMode={() => {
              setIsImageMode(prev => !prev);
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            voiceMode={voiceMode}
            isListening={isListening}
            isSpeaking={isSpeaking}
            onMicClick={handleMicClick}
            onToggleVoice={toggleVoiceMode}
            companionMode={companionMode}
          />
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerBtn: { padding: 6 },
  headerTitleBtn: { alignItems: 'center' },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: -0.3,
  },
  headerSubtitle: {
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    color: '#f472b6',
    opacity: 0.8,
    marginTop: -2,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  voiceBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 6,
    borderBottomWidth: 1,
  },
  voiceDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  voiceBarText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  listContent: {
    paddingTop: 12,
    paddingBottom: 8,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    gap: 12,
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    marginBottom: 4,
  },
  emptyTitle: {
    fontSize: 26,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: -0.5,
  },
  emptySubtitle: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    lineHeight: 22,
  },
  promptsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'center',
    marginTop: 8,
  },
  promptChip: {
    width: '47%',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  promptText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    lineHeight: 19,
  },
});
