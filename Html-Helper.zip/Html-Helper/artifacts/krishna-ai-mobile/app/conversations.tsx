import React from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  Platform,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useChat, Conversation } from '@/context/ChatContext';

function formatDate(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const diff = now.getTime() - ts;
  if (diff < 86400000) {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  if (diff < 604800000) {
    return d.toLocaleDateString([], { weekday: 'short' });
  }
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

interface ItemProps {
  item: Conversation;
  isActive: boolean;
  onSelect: () => void;
  onDelete: () => void;
}

function ConversationItem({ item, isActive, onSelect, onDelete }: ItemProps) {
  const colors = useColors();

  function confirmDelete() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert('Delete Chat', `Delete "${item.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: onDelete },
    ]);
  }

  return (
    <Pressable
      onPress={onSelect}
      style={({ pressed }) => [
        styles.item,
        {
          backgroundColor: isActive ? colors.muted : 'transparent',
          borderColor: isActive ? colors.border : 'transparent',
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <View style={styles.itemLeft}>
        <Feather
          name="message-square"
          size={16}
          color={isActive ? colors.primary : colors.mutedForeground}
        />
        <View style={styles.itemText}>
          <Text
            style={[
              styles.itemTitle,
              { color: isActive ? colors.foreground : colors.foreground },
              isActive && { fontFamily: 'Inter_500Medium' },
            ]}
            numberOfLines={1}
          >
            {item.title}
          </Text>
          <Text style={[styles.itemDate, { color: colors.mutedForeground }]}>
            {formatDate(item.updatedAt)} · {item.messages.length} msg
            {item.messages.length !== 1 ? 's' : ''}
          </Text>
        </View>
      </View>
      <Pressable
        onPress={confirmDelete}
        hitSlop={8}
        style={({ pressed }) => ({ opacity: pressed ? 0.5 : 1 })}
      >
        <Feather name="trash-2" size={15} color={colors.mutedForeground} />
      </Pressable>
    </Pressable>
  );
}

export default function ConversationsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const {
    conversations,
    currentConversationId,
    createConversation,
    selectConversation,
    deleteConversation,
  } = useChat();

  const webTop = Platform.OS === 'web' ? 67 : 0;
  const webBottom = Platform.OS === 'web' ? 34 : 0;

  function handleSelect(id: string) {
    selectConversation(id);
    router.back();
  }

  function handleNew() {
    createConversation();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.back();
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + webTop,
            borderBottomColor: colors.border,
            backgroundColor: colors.card,
          },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Chats</Text>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.closeBtn, { opacity: pressed ? 0.6 : 1 }]}
          hitSlop={8}
        >
          <Feather name="x" size={22} color={colors.foreground} />
        </Pressable>
      </View>

      {/* New Chat button */}
      <Pressable
        onPress={handleNew}
        style={({ pressed }) => [
          styles.newBtn,
          {
            backgroundColor: colors.primary,
            marginHorizontal: 16,
            marginTop: 12,
            opacity: pressed ? 0.85 : 1,
          },
        ]}
      >
        <Feather name="plus" size={18} color={colors.primaryForeground} />
        <Text style={[styles.newBtnText, { color: colors.primaryForeground }]}>
          New Chat
        </Text>
      </Pressable>

      {/* List */}
      {conversations.length === 0 ? (
        <View style={styles.empty}>
          <Feather name="message-square" size={32} color={colors.mutedForeground} />
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            No conversations yet
          </Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <ConversationItem
              item={item}
              isActive={item.id === currentConversationId}
              onSelect={() => handleSelect(item.id)}
              onDelete={() => deleteConversation(item.id)}
            />
          )}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: insets.bottom + webBottom + 16 },
          ]}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: -0.3,
  },
  closeBtn: {
    padding: 4,
  },
  newBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderRadius: 12,
    paddingVertical: 13,
    marginBottom: 8,
  },
  newBtnText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  listContent: {
    paddingTop: 4,
    paddingHorizontal: 8,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 10,
    marginVertical: 1,
    borderWidth: 1,
  },
  itemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    marginRight: 8,
  },
  itemText: {
    flex: 1,
    gap: 2,
  },
  itemTitle: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
  itemDate: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  emptyText: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
  },
});
