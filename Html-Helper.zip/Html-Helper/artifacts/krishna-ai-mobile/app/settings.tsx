import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
  Platform,
  TextInput,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useChat, Settings } from '@/context/ChatContext';

const MODELS = [
  { id: 'gpt-4o-mini', label: 'GPT-4o Mini', description: 'Fast & efficient' },
  { id: 'gpt-4o', label: 'GPT-4o', description: 'Most capable' },
  { id: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo', description: 'Classic' },
];

const LANGUAGES = [
  'English', 'Hindi', 'Hinglish', 'Spanish', 'French',
  'German', 'Japanese', 'Chinese', 'Arabic', 'Portuguese', 'Russian',
];

const TEMP_LABELS: Record<string, string> = {
  '0': 'Precise',
  '0.3': 'Focused',
  '0.5': 'Balanced',
  '0.7': 'Creative',
  '1': 'Wild',
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>{title}</Text>
      {children}
    </View>
  );
}

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const { settings, setSettings } = useChat();

  const [local, setLocal] = useState<Settings>({ ...settings });
  const webTop = Platform.OS === 'web' ? 67 : 0;
  const webBottom = Platform.OS === 'web' ? 34 : 0;

  function save() {
    setSettings(local);
    router.back();
  }

  const tempOptions = [0, 0.3, 0.5, 0.7, 1];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + webTop,
            borderBottomColor: colors.border,
            backgroundColor: colors.card,
          },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Settings</Text>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.closeBtn, { opacity: pressed ? 0.6 : 1 }]}
          hitSlop={8}
        >
          <Feather name="x" size={22} color={colors.foreground} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + webBottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Model */}
        <Section title="MODEL">
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {MODELS.map((m, i) => (
              <Pressable
                key={m.id}
                onPress={() => setLocal(prev => ({ ...prev, model: m.id }))}
                style={({ pressed }) => [
                  styles.optionRow,
                  i < MODELS.length - 1 && {
                    borderBottomWidth: 1,
                    borderBottomColor: colors.border,
                  },
                  { opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <View style={styles.optionText}>
                  <Text style={[styles.optionLabel, { color: colors.foreground }]}>
                    {m.label}
                  </Text>
                  <Text style={[styles.optionDesc, { color: colors.mutedForeground }]}>
                    {m.description}
                  </Text>
                </View>
                {local.model === m.id && (
                  <Feather name="check" size={18} color={colors.primary} />
                )}
              </Pressable>
            ))}
          </View>
        </Section>

        {/* Language */}
        <Section title="LANGUAGE">
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.langGrid}>
              {LANGUAGES.map(lang => (
                <Pressable
                  key={lang}
                  onPress={() => setLocal(prev => ({ ...prev, language: lang }))}
                  style={({ pressed }) => [
                    styles.langChip,
                    {
                      backgroundColor:
                        local.language === lang ? colors.primary : colors.muted,
                      borderColor:
                        local.language === lang ? colors.primary : colors.border,
                      opacity: pressed ? 0.7 : 1,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.langText,
                      {
                        color:
                          local.language === lang
                            ? colors.primaryForeground
                            : colors.foreground,
                      },
                    ]}
                  >
                    {lang}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </Section>

        {/* Temperature */}
        <Section title="CREATIVITY">
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.tempRow}>
              {tempOptions.map(t => {
                const key = t.toString();
                const active = local.temperature === t;
                return (
                  <Pressable
                    key={key}
                    onPress={() => setLocal(prev => ({ ...prev, temperature: t }))}
                    style={({ pressed }) => [
                      styles.tempChip,
                      {
                        backgroundColor: active ? colors.primary : colors.muted,
                        flex: 1,
                        opacity: pressed ? 0.7 : 1,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.tempLabel,
                        {
                          color: active
                            ? colors.primaryForeground
                            : colors.mutedForeground,
                        },
                      ]}
                    >
                      {TEMP_LABELS[key]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </Section>

        {/* System Prompt */}
        <Section title="CUSTOM INSTRUCTIONS">
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TextInput
              style={[
                styles.promptInput,
                { color: colors.foreground, borderColor: colors.input },
              ]}
              value={local.systemPrompt}
              onChangeText={v => setLocal(prev => ({ ...prev, systemPrompt: v }))}
              placeholder="e.g. Always reply in bullet points"
              placeholderTextColor={colors.mutedForeground}
              multiline
              numberOfLines={4}
              keyboardAppearance="dark"
              selectionColor={colors.primary}
            />
          </View>
        </Section>
      </ScrollView>

      {/* Save button */}
      <View
        style={[
          styles.footer,
          {
            paddingBottom: insets.bottom + webBottom + 12,
            backgroundColor: colors.background,
            borderTopColor: colors.border,
          },
        ]}
      >
        <Pressable
          onPress={save}
          style={({ pressed }) => [
            styles.saveBtn,
            { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Text style={[styles.saveBtnText, { color: colors.primaryForeground }]}>
            Save Settings
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: -0.3,
  },
  closeBtn: { padding: 4 },
  content: {
    paddingTop: 20,
    paddingHorizontal: 16,
    gap: 20,
  },
  section: { gap: 8 },
  sectionTitle: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: 0.8,
    marginLeft: 4,
  },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  optionText: { gap: 2 },
  optionLabel: {
    fontSize: 15,
    fontFamily: 'Inter_500Medium',
  },
  optionDesc: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
  langGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    padding: 12,
  },
  langChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  langText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  tempRow: {
    flexDirection: 'row',
    gap: 6,
    padding: 12,
  },
  tempChip: {
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  tempLabel: {
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
  promptInput: {
    padding: 14,
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    lineHeight: 21,
    minHeight: 100,
    textAlignVertical: 'top',
    borderWidth: 0,
  },
  footer: {
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  saveBtn: {
    borderRadius: 14,
    paddingVertical: 15,
    alignItems: 'center',
  },
  saveBtnText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
});
