import React, { forwardRef, useState } from 'react';
import {
  View,
  TextInput,
  Pressable,
  StyleSheet,
  Platform,
  Animated,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { EmojiPicker } from './EmojiPicker';

interface Props {
  onSend: (text: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  isImageMode: boolean;
  onToggleMode: () => void;
}

export const ChatInput = forwardRef<TextInput, Props>(function ChatInput(
  { onSend, onStop, isStreaming, isImageMode, onToggleMode },
  ref,
) {
  const colors = useColors();
  const [text, setText] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);

  const accentColor = isImageMode ? colors.violet : colors.primary;

  function handleSend() {
    const trimmed = text.trim();
    if (!trimmed || isStreaming) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onSend(trimmed);
    setText('');
    setShowEmoji(false);
  }

  function handleEmojiSelect(emoji: string) {
    setText((prev) => prev + emoji);
  }

  function handleToggleEmoji() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setShowEmoji((s) => !s);
  }

  const canSend = text.trim().length > 0 && !isStreaming;

  return (
    <View style={{ backgroundColor: colors.card }}>
      {/* Emoji Picker (appears above input) */}
      {showEmoji && (
        <EmojiPicker
          onSelectEmoji={handleEmojiSelect}
          onClose={() => setShowEmoji(false)}
        />
      )}

      {/* Input row */}
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.card,
            borderColor: isImageMode ? colors.violet : showEmoji ? accentColor : colors.border,
            borderTopWidth: 1,
          },
        ]}
      >
        <View style={styles.row}>
          {/* Mode toggle */}
          <Pressable
            onPress={() => { onToggleMode(); setShowEmoji(false); }}
            style={({ pressed }) => [
              styles.iconBtn,
              {
                backgroundColor: isImageMode ? colors.violetDim : colors.muted,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            hitSlop={8}
          >
            <Feather
              name={isImageMode ? 'image' : 'message-circle'}
              size={17}
              color={accentColor}
            />
          </Pressable>

          {/* Emoji toggle */}
          <Pressable
            onPress={handleToggleEmoji}
            style={({ pressed }) => [
              styles.iconBtn,
              {
                backgroundColor: showEmoji ? accentColor + '33' : colors.muted,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            hitSlop={8}
          >
            <Feather
              name="smile"
              size={17}
              color={showEmoji ? accentColor : colors.mutedForeground}
            />
          </Pressable>

          {/* Text input */}
          <TextInput
            ref={ref}
            style={[styles.input, { color: colors.foreground }]}
            value={text}
            onChangeText={setText}
            placeholder={isImageMode ? 'Describe an image…' : 'Message KrishnaAI…'}
            placeholderTextColor={colors.mutedForeground}
            multiline
            maxLength={4000}
            blurOnSubmit={false}
            onSubmitEditing={Platform.OS !== 'ios' ? handleSend : undefined}
            returnKeyType="send"
            keyboardAppearance="dark"
            selectionColor={accentColor}
            onFocus={() => setShowEmoji(false)}
          />

          {/* Send / Stop */}
          {isStreaming ? (
            <Pressable
              onPress={onStop}
              style={({ pressed }) => [
                styles.sendBtn,
                { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Feather name="square" size={16} color={colors.foreground} />
            </Pressable>
          ) : (
            <Pressable
              onPress={handleSend}
              disabled={!canSend}
              style={({ pressed }) => [
                styles.sendBtn,
                {
                  backgroundColor: canSend ? accentColor : colors.muted,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Feather
                name="arrow-up"
                size={18}
                color={canSend ? colors.primaryForeground : colors.mutedForeground}
              />
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    maxHeight: 120,
    paddingTop: 8,
    paddingBottom: 8,
    lineHeight: 21,
  },
  sendBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
});
