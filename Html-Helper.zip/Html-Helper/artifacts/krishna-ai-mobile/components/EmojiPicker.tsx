import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  ScrollView,
  FlatList,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { useColors } from '@/hooks/useColors';

const COLS = 8;
const ITEM_SIZE = Math.floor((Dimensions.get('window').width - 32) / COLS);

const EMOJI_CATEGORIES: { label: string; icon: string; emojis: string[] }[] = [
  {
    label: 'Smileys',
    icon: '😀',
    emojis: ['😀','😂','🥰','😍','🤩','😎','🥳','😴','🤔','😅','😭','😤','🙄','😏','🤗','😊','🥺','😢','😡','🤫','😇','🥱','😬','🤪','😜','😝','🤑','🤠','😈','👿'],
  },
  {
    label: 'Gestures',
    icon: '👋',
    emojis: ['👍','👎','👏','🙌','🤝','👊','✊','🤞','🤙','💪','✌️','🤘','☝️','👌','🤏','🤚','✋','🖐️','👋','🤜','🤛','👐','🙏','💅','🫶','❤️‍🔥','🤌','🫵','🖖','🤟'],
  },
  {
    label: 'Hearts',
    icon: '❤️',
    emojis: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','♥️','❤️‍🩹','🩷','🩵','🩶','💌','💋','😘','😗','😚','😙'],
  },
  {
    label: 'Fun',
    icon: '🎉',
    emojis: ['🎉','🎊','🎈','🎂','🎁','🎀','🏆','🥇','🎯','🎮','🎲','🎭','🎨','🎬','🎤','🎵','🎶','🎸','🎹','🎺','🎻','🥁','🎷','🎠','🎡','🎢','🎪','🎰','🃏','🎴'],
  },
  {
    label: 'Nature',
    icon: '🌸',
    emojis: ['🌸','🌺','🌻','🌹','🌷','🌼','🍀','🌿','🍃','🍂','🍁','🌾','🌵','🌴','🌳','🌲','🍄','🌙','⭐','🌟','✨','💫','⚡','🔥','❄️','🌈','🌊','🌪️','☀️','🌦️'],
  },
  {
    label: 'Animals',
    icon: '🐶',
    emojis: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔','🐧','🐦','🦋','🐝','🐬','🦈','🐙','🦑','🐳','🦝','🦨','🦡','🦦','🦥'],
  },
  {
    label: 'Food',
    icon: '🍕',
    emojis: ['🍕','🍔','🌮','🍣','🍜','🍛','🍝','🍱','🥗','🥘','🍲','🥙','🌯','🥪','🍞','🥐','🧁','🎂','🍰','🍩','🍪','🍫','🍬','🍭','☕','🍵','🧃','🥤','🍺','🥂'],
  },
  {
    label: 'Symbols',
    icon: '💯',
    emojis: ['💯','🔥','✅','❌','⚠️','💡','🔑','🗝️','💰','💸','💎','🏅','🎯','📌','📍','🔗','📎','✏️','📝','📊','📈','📉','🔍','🔎','💬','💭','🗣️','📢','📣','🔔'],
  },
];

interface Props {
  onSelectEmoji: (emoji: string) => void;
  onClose: () => void;
}

export function EmojiPicker({ onSelectEmoji, onClose }: Props) {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState(0);
  const category = EMOJI_CATEGORIES[activeTab]!;

  return (
    <View style={[styles.container, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
      {/* Tab bar */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.tabBar}
      >
        {EMOJI_CATEGORIES.map((cat, i) => (
          <Pressable
            key={cat.label}
            onPress={() => setActiveTab(i)}
            style={({ pressed }) => [
              styles.tab,
              {
                backgroundColor: activeTab === i ? colors.primary + '33' : 'transparent',
                borderColor: activeTab === i ? colors.primary + '66' : 'transparent',
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <Text style={styles.tabEmoji}>{cat.icon}</Text>
          </Pressable>
        ))}
        {/* Close button */}
        <Pressable
          onPress={onClose}
          style={({ pressed }) => [
            styles.tab,
            { backgroundColor: colors.muted, marginLeft: 8, opacity: pressed ? 0.7 : 1 },
          ]}
        >
          <Text style={[styles.tabEmoji, { color: colors.mutedForeground }]}>✕</Text>
        </Pressable>
      </ScrollView>

      {/* Category label */}
      <Text style={[styles.categoryLabel, { color: colors.mutedForeground }]}>
        {category.icon} {category.label}
      </Text>

      {/* Emoji grid */}
      <FlatList
        data={category.emojis}
        keyExtractor={(item) => item}
        numColumns={COLS}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.grid}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => onSelectEmoji(item)}
            style={({ pressed }) => [
              styles.emojiBtn,
              { width: ITEM_SIZE, height: ITEM_SIZE, opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <Text style={styles.emoji}>{item}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderTopWidth: 1,
    paddingBottom: 8,
    maxHeight: 280,
  },
  tabBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 4,
  },
  tab: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  tabEmoji: {
    fontSize: 18,
  },
  categoryLabel: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    paddingHorizontal: 16,
    paddingBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  grid: {
    paddingHorizontal: 12,
  },
  emojiBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
  },
  emoji: {
    fontSize: 22,
  },
});
