import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Pressable,
  ActivityIndicator,
  Linking,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { Message } from '@/lib/api';

interface Props {
  message: Message;
}

interface ImageContent {
  type: 'image';
  url: string;
  prompt: string;
}

function parseImageContent(content: string): ImageContent | null {
  try {
    const parsed = JSON.parse(content) as ImageContent;
    if (parsed.type === 'image' && parsed.url) return parsed;
    return null;
  } catch {
    return null;
  }
}

export function MessageBubble({ message }: Props) {
  const colors = useColors();
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);

  // Detect image content
  const imageContent = !isUser ? parseImageContent(message.content) : null;
  const isGenerating = !isUser && message.isImage && !imageContent;

  async function handleCopy() {
    await Clipboard.setStringAsync(message.content);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (imageContent) {
    return (
      <View style={[styles.imageWrapper]}>
        <Text style={[styles.imagePromptLabel, { color: colors.mutedForeground }]}>
          {imageContent.prompt}
        </Text>
        <Image
          source={{ uri: imageContent.url }}
          style={[styles.generatedImage, { borderColor: colors.border }]}
          resizeMode="cover"
        />
        <Pressable
          style={[styles.openImageBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => Linking.openURL(imageContent.url)}
        >
          <Feather name="external-link" size={14} color={colors.primary} />
          <Text style={[styles.openImageText, { color: colors.primary }]}>Open full size</Text>
        </Pressable>
      </View>
    );
  }

  if (isGenerating) {
    return (
      <View style={[styles.assistantRow]}>
        <View style={[
          styles.assistantBubble,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}>
          <View style={styles.generatingRow}>
            <ActivityIndicator size="small" color={colors.violet} />
            <Text style={[styles.generatingText, { color: colors.violet }]}>
              Generating image…
            </Text>
          </View>
        </View>
      </View>
    );
  }

  if (isUser) {
    return (
      <View style={styles.userRow}>
        <View style={[styles.userBubble, { backgroundColor: colors.primary }]}>
          <Text style={[styles.userText, { color: colors.primaryForeground }]}>
            {message.content}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.assistantRow}>
      <View style={[
        styles.assistantBubble,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}>
        <Text style={[styles.assistantText, { color: colors.foreground }]}>
          {message.content}
        </Text>
      </View>
      <Pressable
        onPress={handleCopy}
        style={({ pressed }) => [styles.copyBtn, { opacity: pressed ? 0.5 : 1 }]}
      >
        <Feather
          name={copied ? 'check' : 'copy'}
          size={13}
          color={copied ? colors.success : colors.mutedForeground}
        />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  userRow: {
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    marginBottom: 6,
  },
  userBubble: {
    maxWidth: '80%',
    borderRadius: 20,
    borderBottomRightRadius: 6,
    paddingHorizontal: 16,
    paddingVertical: 11,
  },
  userText: {
    fontSize: 15,
    lineHeight: 22,
    fontFamily: 'Inter_400Regular',
  },
  assistantRow: {
    paddingHorizontal: 16,
    marginBottom: 6,
    alignItems: 'flex-start',
  },
  assistantBubble: {
    maxWidth: '88%',
    borderRadius: 20,
    borderTopLeftRadius: 6,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
  },
  assistantText: {
    fontSize: 15,
    lineHeight: 23,
    fontFamily: 'Inter_400Regular',
  },
  copyBtn: {
    marginTop: 4,
    marginLeft: 4,
    padding: 4,
  },
  generatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  generatingText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
  imageWrapper: {
    paddingHorizontal: 16,
    marginBottom: 10,
    alignItems: 'flex-start',
  },
  imagePromptLabel: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    marginBottom: 6,
    fontStyle: 'italic',
  },
  generatedImage: {
    width: 280,
    height: 280,
    borderRadius: 16,
    borderWidth: 1,
  },
  openImageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
  },
  openImageText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
});
