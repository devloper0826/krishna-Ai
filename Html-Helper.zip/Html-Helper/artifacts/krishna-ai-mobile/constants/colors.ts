/**
 * KrishnaAI design tokens — synced from sibling web artifact (index.css)
 * Dark theme is default (matches the web app). Light theme available too.
 */

const colors = {
  dark: {
    text: '#f2f2f2',
    tint: '#0ccff2',

    background: '#09090e',
    foreground: '#f2f2f2',

    card: '#0d0d15',
    cardForeground: '#f2f2f2',

    primary: '#0ccff2',
    primaryForeground: '#09090e',

    secondary: '#161620',
    secondaryForeground: '#f2f2f2',

    muted: '#161620',
    mutedForeground: '#63637a',

    accent: '#161620',
    accentForeground: '#f2f2f2',

    destructive: '#ef4444',
    destructiveForeground: '#f2f2f2',

    border: '#161620',
    input: '#1c1c28',

    violet: '#8b5cf6',
    violetDim: '#1e1040',
    violetFg: '#c4b5fd',

    success: '#10b981',
  },

  light: {
    text: '#0a0a14',
    tint: '#0baccc',

    background: '#f5f5f8',
    foreground: '#0a0a14',

    card: '#ffffff',
    cardForeground: '#0a0a14',

    primary: '#0baccc',
    primaryForeground: '#ffffff',

    secondary: '#f0f0f5',
    secondaryForeground: '#0a0a14',

    muted: '#f0f0f5',
    mutedForeground: '#737390',

    accent: '#e8f9fc',
    accentForeground: '#0a0a14',

    destructive: '#ef4444',
    destructiveForeground: '#ffffff',

    border: '#e5e5f0',
    input: '#e8e8f2',

    violet: '#8b5cf6',
    violetDim: '#f3f0ff',
    violetFg: '#6d28d9',

    success: '#10b981',
  },

  // Border radius in px
  radius: 14,
};

export default colors;
