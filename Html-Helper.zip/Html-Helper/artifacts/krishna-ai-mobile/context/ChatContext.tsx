import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Message } from '@/lib/api';

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

export interface Settings {
  model: string;
  temperature: number;
  language: string;
  systemPrompt: string;
}

interface ChatContextType {
  conversations: Conversation[];
  currentConversationId: string | null;
  currentConversation: Conversation | null;
  settings: Settings;
  setSettings: (s: Settings) => void;
  createConversation: () => string;
  selectConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  addMessage: (conversationId: string, message: Message) => void;
  updateLastMessage: (conversationId: string, content: string) => void;
  updateConversationTitle: (conversationId: string, title: string) => void;
  saveCurrentToStorage: () => void;
}

const DEFAULT_SETTINGS: Settings = {
  model: 'gpt-4o-mini',
  temperature: 0.7,
  language: 'English',
  systemPrompt: '',
};

const ChatContext = createContext<ChatContextType | null>(null);
const STORAGE_KEY = 'krishna_conversations_v2';
const SETTINGS_KEY = 'krishna_settings_v2';

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [settings, setSettingsState] = useState<Settings>(DEFAULT_SETTINGS);
  const initializedRef = useRef(false);
  const convsRef = useRef<Conversation[]>([]);

  // Keep ref in sync so callbacks can access latest state
  useEffect(() => {
    convsRef.current = conversations;
  }, [conversations]);

  useEffect(() => {
    if (initializedRef.current) return;
    initializedRef.current = true;
    (async () => {
      try {
        const [storedConvs, storedSettings] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(SETTINGS_KEY),
        ]);
        if (storedConvs) {
          const convs: Conversation[] = JSON.parse(storedConvs);
          setConversations(convs);
          convsRef.current = convs;
          if (convs.length > 0) setCurrentId(convs[0].id);
        }
        if (storedSettings) {
          setSettingsState(JSON.parse(storedSettings));
        }
      } catch {}
    })();
  }, []);

  function persist(convs: Conversation[]) {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(convs)).catch(() => {});
  }

  function setSettings(s: Settings) {
    setSettingsState(s);
    AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s)).catch(() => {});
  }

  function createConversation(): string {
    const id = `conv-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newConv: Conversation = {
      id,
      title: 'New Chat',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations(prev => {
      const updated = [newConv, ...prev];
      persist(updated);
      return updated;
    });
    setCurrentId(id);
    return id;
  }

  function selectConversation(id: string) {
    setCurrentId(id);
  }

  function deleteConversation(id: string) {
    setConversations(prev => {
      const updated = prev.filter(c => c.id !== id);
      persist(updated);
      return updated;
    });
    setCurrentId(prev => {
      if (prev !== id) return prev;
      const remaining = convsRef.current.filter(c => c.id !== id);
      return remaining.length > 0 ? remaining[0].id : null;
    });
  }

  function addMessage(conversationId: string, message: Message) {
    setConversations(prev => {
      const updated = prev.map(c => {
        if (c.id !== conversationId) return c;
        return { ...c, messages: [...c.messages, message], updatedAt: Date.now() };
      });
      persist(updated);
      return updated;
    });
  }

  function updateLastMessage(conversationId: string, content: string) {
    setConversations(prev => {
      const updated = prev.map(c => {
        if (c.id !== conversationId) return c;
        const msgs = [...c.messages];
        if (msgs.length > 0) {
          msgs[msgs.length - 1] = { ...msgs[msgs.length - 1], content };
        }
        return { ...c, messages: msgs, updatedAt: Date.now() };
      });
      return updated;
    });
  }

  function updateConversationTitle(conversationId: string, title: string) {
    setConversations(prev => {
      const updated = prev.map(c =>
        c.id === conversationId ? { ...c, title } : c,
      );
      persist(updated);
      return updated;
    });
  }

  function saveCurrentToStorage() {
    persist(convsRef.current);
  }

  const currentConversation = conversations.find(c => c.id === currentId) ?? null;

  return (
    <ChatContext.Provider
      value={{
        conversations,
        currentConversationId: currentId,
        currentConversation,
        settings,
        setSettings,
        createConversation,
        selectConversation,
        deleteConversation,
        addMessage,
        updateLastMessage,
        updateConversationTitle,
        saveCurrentToStorage,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used inside ChatProvider');
  return ctx;
}
