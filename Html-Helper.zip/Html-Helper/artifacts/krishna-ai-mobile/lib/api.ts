import { fetch } from 'expo/fetch';

export function getBaseUrl(): string {
  const domain = process.env.EXPO_PUBLIC_DOMAIN;
  return domain ? `https://${domain}` : '';
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isImage?: boolean;
}

let _counter = 0;
export function generateMessageId(): string {
  _counter++;
  return `msg-${Date.now()}-${_counter}-${Math.random().toString(36).substr(2, 9)}`;
}

export async function streamChat(
  messages: { role: string; content: string }[],
  options: { model?: string; temperature?: number; systemPrompt?: string },
  onChunk: (text: string) => void,
  signal?: AbortSignal,
): Promise<void> {
  const base = getBaseUrl();
  const response = await fetch(`${base}/api/mobile/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
    },
    body: JSON.stringify({ messages, ...options }),
    signal,
  });

  if (!response.ok) {
    const text = await response.text().catch(() => 'Request failed');
    throw new Error(text);
  }

  const reader = response.body?.getReader();
  if (!reader) throw new Error('No response body');

  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6);
      if (data === '[DONE]') continue;
      try {
        const parsed = JSON.parse(data) as { content?: string; error?: string };
        if (parsed.error) throw new Error(parsed.error);
        if (parsed.content) onChunk(parsed.content);
      } catch (e) {
        if (e instanceof Error && e.message !== 'Unexpected token') throw e;
      }
    }
  }
}

export async function generateImage(prompt: string): Promise<string> {
  const base = getBaseUrl();
  const response = await fetch(`${base}/api/mobile/generate-image`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  });
  const data = await response.json() as { url?: string; error?: string };
  if (!response.ok || data.error) throw new Error(data.error ?? 'Image generation failed');
  if (!data.url) throw new Error('No image URL returned');
  return data.url;
}
