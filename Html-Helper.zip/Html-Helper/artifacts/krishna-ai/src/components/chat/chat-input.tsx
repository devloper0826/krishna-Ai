import React, { useState, useRef, useEffect } from "react";
import { SendHorizontal, Square, ImageIcon, MessageSquare, Sparkles, Smile, X, Mic, MicOff, Volume2, VolumeX } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSend: (message: string) => void;
  onSendImage?: (prompt: string) => void;
  onStop?: () => void;
  disabled?: boolean;
  isListening?: boolean;
  isSpeaking?: boolean;
  voiceMode?: boolean;
  onToggleVoice?: () => void;
  onMicClick?: () => void;
  companionMode?: boolean;
}

const MAX_CHARS = 4000;

const EMOJI_CATEGORIES: { label: string; icon: string; emojis: string[] }[] = [
  {
    label: "Smileys",
    icon: "😀",
    emojis: ["😀","😂","🥰","😍","🤩","😎","🥳","😴","🤔","😅","😭","😤","🙄","😏","🤗","😊","🥺","😢","😡","🤫","😇","🥱","😬","🤪","😜","😝","🤑","🤠","😈","👿"],
  },
  {
    label: "Gestures",
    icon: "👋",
    emojis: ["👍","👎","👏","🙌","🤝","👊","✊","🤞","🤙","💪","✌️","🤘","☝️","👌","🤏","🤚","✋","🖐️","👋","🤜","🤛","👐","🙏","💅","🫶","❤️‍🔥","🤌","🫵","🖖","🤟"],
  },
  {
    label: "Hearts",
    icon: "❤️",
    emojis: ["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","♥️","❤️‍🩹","🩷","🩵","🩶","💌","💋","😘","😗","😚","😙"],
  },
  {
    label: "Fun",
    icon: "🎉",
    emojis: ["🎉","🎊","🎈","🎂","🎁","🎀","🏆","🥇","🎯","🎮","🎲","🎭","🎨","🎬","🎤","🎵","🎶","🎸","🎹","🎺","🎻","🥁","🎷","🎠","🎡","🎢","🎪","🎰","🃏","🎴"],
  },
  {
    label: "Nature",
    icon: "🌸",
    emojis: ["🌸","🌺","🌻","🌹","🌷","🌼","🍀","🌿","🍃","🍂","🍁","🌾","🌵","🌴","🌳","🌲","🍄","🌙","⭐","🌟","✨","💫","⚡","🔥","❄️","🌈","🌊","🌪️","☀️","🌦️"],
  },
  {
    label: "Animals",
    icon: "🐶",
    emojis: ["🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐸","🐵","🐔","🐧","🐦","🦋","🐝","🐬","🦈","🐙","🦑","🐳","🦝","🦨","🦡","🦦","🦥"],
  },
  {
    label: "Food",
    icon: "🍕",
    emojis: ["🍕","🍔","🌮","🍣","🍜","🍛","🍝","🍱","🥗","🥘","🍲","🥙","🌯","🥪","🍞","🥐","🧁","🎂","🍰","🍩","🍪","🍫","🍬","🍭","☕","🍵","🧃","🥤","🍺","🥂"],
  },
  {
    label: "Symbols",
    icon: "💯",
    emojis: ["💯","🔥","✅","❌","⚠️","💡","🔑","🗝️","💰","💸","💎","🏅","🎯","📌","📍","🔗","📎","✏️","📝","📊","📈","📉","🔍","🔎","💬","💭","🗣️","📢","📣","🔔"],
  },
];

export function ChatInput({
  onSend, onSendImage, onStop, disabled,
  isListening = false, isSpeaking = false, voiceMode = false,
  onToggleVoice, onMicClick, companionMode = false,
}: ChatInputProps) {
  const [value, setValue] = useState("");
  const [imageMode, setImageMode] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [emojiTab, setEmojiTab] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const emojiPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "24px";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [value]);

  useEffect(() => {
    textareaRef.current?.focus();
    setValue("");
  }, [imageMode]);

  useEffect(() => {
    if (!showEmoji) return;
    const handler = (e: MouseEvent) => {
      if (emojiPickerRef.current && !emojiPickerRef.current.contains(e.target as Node)) {
        setShowEmoji(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [showEmoji]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
    if (e.key === "Escape") setShowEmoji(false);
  };

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed || disabled || value.length > MAX_CHARS) return;
    imageMode ? onSendImage?.(trimmed) : onSend(trimmed);
    setValue("");
    setShowEmoji(false);
  };

  const insertEmoji = (emoji: string) => {
    const textarea = textareaRef.current;
    if (!textarea) { setValue((v) => v + emoji); return; }
    const start = textarea.selectionStart ?? value.length;
    const end = textarea.selectionEnd ?? value.length;
    const newVal = value.slice(0, start) + emoji + value.slice(end);
    setValue(newVal);
    requestAnimationFrame(() => {
      textarea.focus();
      const pos = start + emoji.length;
      textarea.setSelectionRange(pos, pos);
    });
  };

  const overLimit = value.length > MAX_CHARS;
  const category = EMOJI_CATEGORIES[emojiTab]!;

  // Border color based on state
  const borderClass = overLimit
    ? "border-destructive focus-within:ring-1 focus-within:ring-destructive"
    : isListening
      ? "border-rose-500/70 ring-1 ring-rose-500/40 shadow-[0_0_16px_rgba(244,63,94,0.15)]"
      : companionMode
        ? "border-pink-500/40 focus-within:ring-1 focus-within:ring-pink-500/60"
        : imageMode
          ? "border-violet-500/40 focus-within:ring-1 focus-within:ring-violet-500/60"
          : showEmoji
            ? "border-primary/60 ring-1 ring-primary/30"
            : "border-border focus-within:ring-1 focus-within:ring-primary focus-within:border-primary";

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      {/* Pills row */}
      <div className="absolute -top-8 left-0 flex items-center gap-2">
        <AnimatePresence>
          {isListening && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
              className="flex items-center gap-1.5 bg-rose-500/20 border border-rose-500/30 text-rose-400 text-[11px] font-mono px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
              Listening…
            </motion.div>
          )}
          {isSpeaking && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
              className="flex items-center gap-1.5 bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 text-[11px] font-mono px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
              Speaking…
            </motion.div>
          )}
          {imageMode && !isListening && !isSpeaking && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
              className="flex items-center gap-1.5 bg-violet-500/20 border border-violet-500/30 text-violet-400 text-[11px] font-mono px-2.5 py-1 rounded-full">
              <Sparkles className="w-3 h-3" />
              Image Mode
            </motion.div>
          )}
          {companionMode && !isListening && !isSpeaking && !imageMode && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
              className="flex items-center gap-1.5 bg-pink-500/20 border border-pink-500/30 text-pink-400 text-[11px] font-mono px-2.5 py-1 rounded-full">
              💋 Priya Mode
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Emoji Picker */}
      <AnimatePresence>
        {showEmoji && (
          <motion.div ref={emojiPickerRef}
            initial={{ opacity: 0, y: 8, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: 0.96 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full mb-2 left-0 right-0 bg-card border border-border rounded-2xl shadow-2xl overflow-hidden z-50">
            {/* Category tabs */}
            <div className="flex items-center gap-0.5 px-2 pt-2 pb-1 border-b border-border overflow-x-auto scrollbar-none">
              {EMOJI_CATEGORIES.map((cat, i) => (
                <button key={cat.label} onClick={() => setEmojiTab(i)} title={cat.label}
                  className={cn("flex-shrink-0 w-8 h-8 rounded-lg text-base flex items-center justify-center transition-all duration-150",
                    emojiTab === i ? "bg-primary/20 ring-1 ring-primary/40" : "hover:bg-muted")}>
                  {cat.icon}
                </button>
              ))}
              <div className="flex-1" />
              <button onClick={() => setShowEmoji(false)}
                className="flex-shrink-0 p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            {/* Emoji grid */}
            <div className="p-2">
              <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider px-1 mb-1.5">{category.label}</p>
              <div className="grid grid-cols-10 gap-0.5">
                {category.emojis.map((emoji) => (
                  <button key={emoji} onClick={() => insertEmoji(emoji)}
                    className="w-8 h-8 rounded-lg text-xl flex items-center justify-center hover:bg-muted transition-colors hover:scale-110 active:scale-95">
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div layout className={cn("bg-card border shadow-lg rounded-2xl p-2 flex items-end gap-1.5 transition-all duration-200", borderClass)}>
        {/* Mode toggle */}
        <button onClick={() => { setImageMode((m) => !m); setShowEmoji(false); }} disabled={disabled}
          title={imageMode ? "Switch to chat" : "Switch to image generation"}
          className={cn("p-2 rounded-xl flex-shrink-0 transition-all duration-200 self-end mb-0.5",
            imageMode ? "bg-violet-500/20 text-violet-400 hover:bg-violet-500/30"
              : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80")}>
          {imageMode ? <MessageSquare className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
        </button>

        {/* Emoji toggle */}
        <button onClick={() => setShowEmoji((s) => !s)} disabled={disabled} title="Emoji picker"
          className={cn("p-2 rounded-xl flex-shrink-0 transition-all duration-200 self-end mb-0.5",
            showEmoji ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80")}>
          <Smile className="w-4 h-4" />
        </button>

        {/* Mic button */}
        {onMicClick && (
          <button
            onClick={onMicClick}
            disabled={disabled && !isListening}
            title={isListening ? "Stop recording" : "Voice input"}
            className={cn("p-2 rounded-xl flex-shrink-0 transition-all duration-200 self-end mb-0.5",
              isListening
                ? "bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 animate-pulse"
                : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80")}>
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
        )}

        {/* Voice auto-speak toggle */}
        {onToggleVoice && (
          <button onClick={onToggleVoice} title={voiceMode ? "Mute voice responses" : "Enable voice responses"}
            className={cn("p-2 rounded-xl flex-shrink-0 transition-all duration-200 self-end mb-0.5",
              voiceMode
                ? isSpeaking ? "bg-cyan-500/30 text-cyan-300 animate-pulse" : "bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80")}>
            {voiceMode ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        )}

        <textarea ref={textareaRef} data-testid="input-message" value={value}
          onChange={(e) => setValue(e.target.value)} onKeyDown={handleKeyDown}
          placeholder={
            isListening ? "Listening to you…" :
            companionMode ? "Talk to Priya…" :
            imageMode ? "Describe an image to generate…" : "Ask KrishnaAI…"
          }
          className="w-full bg-transparent text-foreground placeholder:text-muted-foreground outline-none resize-none px-3 py-2 text-[15px] leading-relaxed max-h-[200px] min-h-[44px]"
          disabled={disabled && !isListening} rows={1} />

        {/* Char counter + action */}
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          {value.length > 0 && (
            <span className={cn("text-[10px] font-mono tabular-nums pr-1",
              overLimit ? "text-destructive" : "text-muted-foreground")}>
              {value.length}/{MAX_CHARS}
            </span>
          )}
          {disabled && !isListening ? (
            <button data-testid="button-stop" onClick={onStop} title="Stop generation"
              className="p-2.5 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition-all duration-200 flex items-center justify-center">
              <Square className="w-5 h-5 fill-current" />
            </button>
          ) : (
            <button data-testid="button-send" onClick={handleSend}
              disabled={!value.trim() || overLimit}
              className={cn("p-2.5 rounded-xl flex-shrink-0 transition-all duration-200 flex items-center justify-center",
                value.trim() && !overLimit
                  ? companionMode
                    ? "bg-gradient-to-br from-pink-500 to-rose-500 text-white hover:opacity-90"
                    : imageMode
                      ? "bg-violet-500 text-white hover:bg-violet-600"
                      : "bg-primary text-primary-foreground hover:opacity-90"
                  : "bg-muted text-muted-foreground opacity-50 cursor-not-allowed")}>
              {imageMode ? <Sparkles className="w-5 h-5" /> : <SendHorizontal className="w-5 h-5" />}
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
