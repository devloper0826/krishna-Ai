import React, { useState } from "react";
import { motion } from "framer-motion";
import { User, Copy, Check, RefreshCw, Download, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { SimpleMarkdown } from "@/lib/markdown";
import { LANGUAGES } from "@/lib/languages";

interface ImageContent {
  type: "image";
  url: string;
  prompt: string;
}

function isImageContent(content: string): ImageContent | null {
  try {
    const parsed = JSON.parse(content);
    if (parsed.type === "image" && typeof parsed.url === "string") return parsed as ImageContent;
  } catch { /* not JSON */ }
  return null;
}

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
  isStreaming?: boolean;
  isGeneratingImage?: boolean;
  language?: string;
  onRegenerate?: () => void;
  onSpeak?: () => void;
  companionMode?: boolean;
}

export function MessageBubble({
  role, content, isStreaming, isGeneratingImage, language,
  onRegenerate, onSpeak, companionMode,
}: MessageBubbleProps) {
  const isUser = role === "user";
  const [copied, setCopied] = useState(false);
  const imageContent = !isUser ? isImageContent(content) : null;

  const langMeta = !isUser && language
    ? LANGUAGES.find((l) => l.code === language)
    : null;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadImage = (url: string, prompt: string) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = `krishnaai-${prompt.slice(0, 30).replace(/[^a-z0-9]/gi, "_")}.png`;
    a.target = "_blank";
    a.click();
  };

  // Companion mode: assistant avatar is 💋 emoji, bubble has pink tint
  const assistantAvatarEl = companionMode ? (
    <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 text-lg bg-gradient-to-br from-pink-500/30 to-rose-500/20 border border-pink-500/30 shadow-[0_0_8px_rgba(236,72,153,0.2)]">
      💋
    </div>
  ) : (
    <img
      src={`${import.meta.env.BASE_URL}favicon.png`}
      alt="KrishnaAI"
      className="w-8 h-8 rounded-full object-cover flex-shrink-0 mt-1 shadow-[0_0_10px_rgba(212,175,55,0.35)]"
    />
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn("flex w-full group", isUser ? "justify-end" : "justify-start")}
    >
      <div className={cn(
        "flex max-w-[85%] sm:max-w-[75%] gap-4 items-start",
        isUser ? "flex-row-reverse" : "flex-row"
      )}>
        {/* Avatar */}
        {isUser ? (
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 shadow-sm bg-secondary text-secondary-foreground">
            <User className="w-4 h-4" />
          </div>
        ) : assistantAvatarEl}

        {/* Bubble + actions */}
        <div className="flex flex-col gap-1.5 min-w-0">
          {/* Image generation loading */}
          {isGeneratingImage && !content ? (
            <div className="px-5 py-4 rounded-2xl bg-card border border-violet-500/20 rounded-tl-sm">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center animate-pulse">
                  <span className="text-lg">🎨</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-violet-400">Generating image…</div>
                  <div className="text-xs text-muted-foreground">This may take a few seconds</div>
                </div>
                <div className="flex gap-1 ml-2">
                  <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse delay-75" />
                  <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse delay-150" />
                  <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse delay-300" />
                </div>
              </div>
            </div>
          ) : imageContent ? (
            /* Image result */
            <div className="rounded-2xl bg-card border border-violet-500/20 overflow-hidden rounded-tl-sm max-w-sm shadow-lg">
              <img
                src={imageContent.url}
                alt={imageContent.prompt}
                className="w-full object-cover"
                loading="lazy"
              />
              <div className="p-3 flex items-center justify-between gap-2">
                <p className="text-xs text-muted-foreground italic truncate flex-1">"{imageContent.prompt}"</p>
                <button
                  onClick={() => handleDownloadImage(imageContent.url, imageContent.prompt)}
                  title="Open full size"
                  className="flex-shrink-0 p-1.5 rounded-md text-violet-400 hover:bg-violet-500/10 transition-colors"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            /* Text bubble */
            <div className={cn(
              "px-5 py-4 rounded-2xl text-[15px] leading-relaxed shadow-sm",
              isUser
                ? "bg-secondary text-secondary-foreground rounded-tr-sm"
                : companionMode
                  ? "bg-gradient-to-br from-pink-950/30 to-card border border-pink-500/20 text-card-foreground rounded-tl-sm"
                  : "bg-card border border-border text-card-foreground rounded-tl-sm"
            )}>
              {isUser ? (
                <div className="whitespace-pre-wrap">{content}</div>
              ) : (
                <div className={cn("min-w-[20px]", isStreaming && !content && "flex h-6 items-center")}>
                  {content ? (
                    <SimpleMarkdown content={content} />
                  ) : (
                    <div className="flex gap-1">
                      <span className={cn("w-2 h-2 rounded-full animate-pulse-fast delay-75", companionMode ? "bg-pink-400" : "bg-primary")} />
                      <span className={cn("w-2 h-2 rounded-full animate-pulse-fast delay-150", companionMode ? "bg-pink-400" : "bg-primary")} />
                      <span className={cn("w-2 h-2 rounded-full animate-pulse-fast delay-300", companionMode ? "bg-pink-400" : "bg-primary")} />
                    </div>
                  )}
                  {isStreaming && content && (
                    <span className={cn("inline-block w-2 h-4 ml-1 animate-pulse align-middle", companionMode ? "bg-pink-400" : "bg-primary")} />
                  )}
                </div>
              )}
            </div>
          )}

          {/* Action row */}
          {content && !isStreaming && !isGeneratingImage && !imageContent && (
            <div className={cn(
              "flex items-center gap-3 px-1 opacity-0 group-hover:opacity-100 transition-opacity",
              isUser ? "justify-end" : "justify-start"
            )}>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
              >
                {copied
                  ? <><Check className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-primary">Copied!</span></>
                  : <><Copy className="w-3.5 h-3.5" /><span className="font-mono">Copy</span></>
                }
              </button>
              {!isUser && onSpeak && (
                <button
                  onClick={onSpeak}
                  className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
                  title="Speak this message"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span className="font-mono">Speak</span>
                </button>
              )}
              {!isUser && onRegenerate && (
                <button onClick={onRegenerate} className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors">
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="font-mono">Regenerate</span>
                </button>
              )}
              {langMeta && (
                <span className="flex items-center gap-1 text-[11px] text-muted-foreground font-mono">
                  <span>{langMeta.flag}</span><span>{langMeta.label}</span>
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
