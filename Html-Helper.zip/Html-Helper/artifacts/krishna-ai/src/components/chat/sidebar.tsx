import React, { useState, useRef, useEffect } from "react";
import { Plus, MessageSquare, Trash2, Pencil, Check, X, ChevronDown, PanelLeftClose, Search, Trash, ChevronRight, LogOut, Mic, Volume2 } from "lucide-react";
import {
  useListOpenaiConversations,
  useDeleteOpenaiConversation,
  useUpdateOpenaiConversation,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useClerk, useUser } from "@clerk/react";
import { cn } from "@/lib/utils";
import { LANGUAGES } from "@/lib/languages";
import { MODELS } from "@/lib/models";

interface SidebarProps {
  activeId: number | null;
  onSelect: (id: number | null) => void;
  language: string;
  onLanguageChange: (lang: string) => void;
  model: string;
  onModelChange: (model: string) => void;
  temperature: number;
  onTemperatureChange: (t: number) => void;
  systemPrompt: string;
  onSystemPromptChange: (s: string) => void;
  companionMode: boolean;
  onCompanionModeChange: (v: boolean) => void;
  voiceMode: boolean;
  onVoiceModeChange: (v: boolean) => void;
  onClose?: () => void;
}

function ConversationItem({ conv, activeId, onSelect, onDelete, onRename }: {
  conv: { id: number; title: string };
  activeId: number | null;
  onSelect: (id: number) => void;
  onDelete: (e: React.MouseEvent, id: number) => void;
  onRename: (id: number, title: string) => Promise<void>;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(conv.title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) { setDraft(conv.title); setTimeout(() => inputRef.current?.select(), 0); }
  }, [editing, conv.title]);

  const handleConfirm = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const trimmed = draft.trim();
    if (trimmed && trimmed !== conv.title) await onRename(conv.id, trimmed);
    setEditing(false);
  };
  const handleCancel = (e?: React.MouseEvent) => { e?.stopPropagation(); setDraft(conv.title); setEditing(false); };
  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === "Enter") handleConfirm(); if (e.key === "Escape") handleCancel(); };

  return (
    <div
      data-testid={`card-conversation-${conv.id}`}
      onClick={() => !editing && onSelect(conv.id)}
      className={cn(
        "group flex items-center justify-between px-3 py-2.5 rounded-md transition-colors text-sm",
        editing ? "cursor-default" : "cursor-pointer",
        activeId === conv.id ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent/50"
      )}
    >
      {editing ? (
        <div className="flex items-center gap-1 flex-1 min-w-0" onClick={(e) => e.stopPropagation()}>
          <input ref={inputRef} value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={handleKeyDown}
            className="flex-1 min-w-0 bg-background border border-primary/40 rounded px-2 py-0.5 text-sm text-foreground focus:outline-none focus:border-primary" />
          <button onClick={handleConfirm} className="text-primary hover:text-primary/80 flex-shrink-0"><Check className="w-3.5 h-3.5" /></button>
          <button onClick={handleCancel} className="text-muted-foreground hover:text-foreground flex-shrink-0"><X className="w-3.5 h-3.5" /></button>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-2 truncate flex-1 min-w-0">
            <MessageSquare className="w-4 h-4 flex-shrink-0 opacity-70" />
            <span className="truncate">{conv.title}</span>
          </div>
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
            <button onClick={(e) => { e.stopPropagation(); setEditing(true); }} className="hover:text-primary transition-colors" title="Rename"><Pencil className="w-3.5 h-3.5" /></button>
            <button onClick={(e) => onDelete(e, conv.id)} className="hover:text-destructive transition-colors" title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        </>
      )}
    </div>
  );
}

export function Sidebar({
  activeId, onSelect, language, onLanguageChange, model, onModelChange,
  temperature, onTemperatureChange, systemPrompt, onSystemPromptChange,
  companionMode, onCompanionModeChange, voiceMode, onVoiceModeChange, onClose,
}: SidebarProps) {
  const queryClient = useQueryClient();
  const { data: conversations, isLoading } = useListOpenaiConversations();
  const deleteMutation = useDeleteOpenaiConversation();
  const renameMutation = useUpdateOpenaiConversation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const [search, setSearch] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    await deleteMutation.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    if (activeId === id) onSelect(null);
  };

  const handleRename = async (id: number, title: string) => {
    await renameMutation.mutateAsync({ id, data: { title } });
    queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
  };

  const handleClearAll = async () => {
    if (!confirmClear) { setConfirmClear(true); setTimeout(() => setConfirmClear(false), 3000); return; }
    await fetch("/api/openai/conversations", { method: "DELETE" });
    queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    onSelect(null);
    setConfirmClear(false);
  };

  const filtered = (conversations ?? []).filter((c) => c.title.toLowerCase().includes(search.toLowerCase()));
  const tempLabel = temperature <= 0.3 ? "Precise" : temperature <= 0.7 ? "Balanced" : temperature <= 1.2 ? "Creative" : "Wild";

  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? " " + user.lastName : ""}`
    : user?.emailAddresses?.[0]?.emailAddress ?? "User";
  const displayEmail = user?.emailAddresses?.[0]?.emailAddress ?? "";
  const avatarUrl = user?.imageUrl;
  const initials = displayName.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div className="w-64 h-full bg-sidebar border-r border-sidebar-border flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border flex items-center gap-3">
        <img src={`${import.meta.env.BASE_URL}favicon.png`} alt="KrishnaAI" className="w-9 h-9 rounded-full object-cover flex-shrink-0 shadow-[0_0_12px_rgba(212,175,55,0.4)]" />
        <div className="leading-tight flex-1">
          <div className="text-sm font-bold text-foreground">KrishnaAI</div>
          <div className="text-[10px] text-muted-foreground font-mono tracking-wide uppercase">Learn Smart. Think Big.</div>
        </div>
        {onClose && (
          <button onClick={onClose} className="md:hidden p-1 rounded text-muted-foreground hover:text-foreground hover:bg-sidebar-accent transition-colors">
            <PanelLeftClose className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* ===== COMPANION MODE CARD ===== */}
      <div className="px-3 pt-3 pb-1">
        <button
          onClick={() => onCompanionModeChange(!companionMode)}
          className={cn(
            "w-full flex items-center gap-2.5 p-3 rounded-xl border transition-all duration-300",
            companionMode
              ? "bg-gradient-to-r from-pink-500/20 via-rose-500/15 to-pink-500/10 border-pink-500/40 shadow-[0_0_16px_rgba(236,72,153,0.12)]"
              : "bg-sidebar-accent/20 border-sidebar-border hover:bg-sidebar-accent/40 hover:border-pink-500/20"
          )}
        >
          <div className={cn(
            "w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0 transition-all",
            companionMode ? "bg-pink-500/30 shadow-[0_0_8px_rgba(236,72,153,0.3)]" : "bg-muted"
          )}>
            💋
          </div>
          <div className="text-left flex-1 min-w-0">
            <div className={cn("text-xs font-semibold", companionMode ? "text-pink-300" : "text-sidebar-foreground")}>
              {companionMode ? "Priya — Active ✨" : "Companion Mode"}
            </div>
            <div className="text-[10px] text-muted-foreground truncate">
              {companionMode ? "Warm, playful AI companion" : "Enable your AI companion"}
            </div>
          </div>
          <div className={cn(
            "w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all",
            companionMode ? "bg-pink-500 border-pink-500 shadow-[0_0_6px_rgba(236,72,153,0.5)]" : "border-muted-foreground/40"
          )} />
        </button>
      </div>

      {/* ===== VOICE MODE CARD ===== */}
      <div className="px-3 pb-2">
        <button
          onClick={() => onVoiceModeChange(!voiceMode)}
          className={cn(
            "w-full flex items-center gap-2.5 p-3 rounded-xl border transition-all duration-300",
            voiceMode
              ? "bg-cyan-500/15 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.1)]"
              : "bg-sidebar-accent/20 border-sidebar-border hover:bg-sidebar-accent/40 hover:border-cyan-500/20"
          )}
        >
          <div className={cn(
            "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all",
            voiceMode ? "bg-cyan-500/25" : "bg-muted"
          )}>
            {voiceMode
              ? <Volume2 className="w-4 h-4 text-cyan-400" />
              : <Mic className="w-4 h-4 text-muted-foreground" />}
          </div>
          <div className="text-left flex-1 min-w-0">
            <div className={cn("text-xs font-semibold", voiceMode ? "text-cyan-300" : "text-sidebar-foreground")}>
              {voiceMode ? "Voice On 🎙️" : "Voice Assistant"}
            </div>
            <div className="text-[10px] text-muted-foreground truncate">
              {voiceMode ? "Mic + auto-speak responses" : "Speak & hear responses"}
            </div>
          </div>
          <div className={cn(
            "w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all",
            voiceMode ? "bg-cyan-500 border-cyan-500" : "border-muted-foreground/40"
          )} />
        </button>
      </div>

      {/* New chat */}
      <div className="px-3 pb-1">
        <button data-testid="button-new-chat" onClick={() => onSelect(null)}
          className="w-full flex items-center gap-2 px-4 py-2.5 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 rounded-md transition-colors font-medium text-sm">
          <Plus className="w-4 h-4" />New Chat
          <span className="ml-auto text-[10px] opacity-50 font-mono">Ctrl+K</span>
        </button>
      </div>

      {/* Search */}
      <div className="px-3 py-1">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search chats…"
            className="w-full bg-sidebar-accent/30 border border-sidebar-border rounded-md pl-8 pr-3 py-1.5 text-sm text-sidebar-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/40 transition-colors" />
        </div>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {isLoading ? (
          <div className="p-4 text-center text-sm text-muted-foreground">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">{search ? "No matches" : "No conversations yet"}</div>
        ) : (
          filtered.map((conv) => (
            <ConversationItem key={conv.id} conv={conv} activeId={activeId} onSelect={onSelect} onDelete={handleDelete} onRename={handleRename} />
          ))
        )}
      </div>

      {/* Settings panel */}
      <div className="border-t border-sidebar-border">
        <button onClick={() => setSettingsOpen((o) => !o)}
          className="w-full flex items-center gap-2 px-4 py-2.5 text-xs text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/40 transition-colors font-mono">
          <ChevronRight className={cn("w-3.5 h-3.5 transition-transform", settingsOpen && "rotate-90")} />
          Settings
        </button>

        {settingsOpen && (
          <div className="px-3 pb-3 space-y-3">
            <div>
              <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider mb-1">Model</div>
              <div className="relative">
                <select value={model} onChange={(e) => onModelChange(e.target.value)}
                  className="w-full appearance-none bg-sidebar-accent/40 hover:bg-sidebar-accent/70 border border-sidebar-border text-sidebar-foreground text-sm rounded-md px-3 py-1.5 pr-8 cursor-pointer focus:outline-none focus:border-primary/50 transition-colors">
                  {MODELS.map((m) => <option key={m.id} value={m.id}>{m.label} — {m.desc}</option>)}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>

            <div>
              <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider mb-1">Language</div>
              <div className="relative">
                <select value={language} onChange={(e) => onLanguageChange(e.target.value)}
                  className="w-full appearance-none bg-sidebar-accent/40 hover:bg-sidebar-accent/70 border border-sidebar-border text-sidebar-foreground text-sm rounded-md px-3 py-1.5 pr-8 cursor-pointer focus:outline-none focus:border-primary/50 transition-colors">
                  {LANGUAGES.map((lang) => <option key={lang.code} value={lang.code}>{lang.flag} {lang.label}</option>)}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">Creativity</div>
                <span className="text-[10px] font-mono text-primary">{tempLabel} ({temperature.toFixed(1)})</span>
              </div>
              <input type="range" min="0" max="2" step="0.1" value={temperature}
                onChange={(e) => onTemperatureChange(parseFloat(e.target.value))}
                className="w-full h-1.5 rounded-full accent-primary cursor-pointer bg-sidebar-accent" />
              <div className="flex justify-between text-[9px] text-muted-foreground font-mono mt-0.5">
                <span>Precise</span><span>Creative</span><span>Wild</span>
              </div>
            </div>

            <div>
              <div className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider mb-1">Custom Instructions</div>
              <textarea value={systemPrompt} onChange={(e) => onSystemPromptChange(e.target.value)}
                placeholder="e.g. Always respond with examples. Be concise."
                rows={3}
                className="w-full bg-sidebar-accent/30 border border-sidebar-border rounded-md px-2.5 py-2 text-xs text-sidebar-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary/40 transition-colors resize-none" />
            </div>

            {(conversations?.length ?? 0) > 0 && (
              <button onClick={handleClearAll}
                className={cn("w-full flex items-center justify-center gap-1.5 py-1.5 rounded-md text-xs font-mono transition-colors",
                  confirmClear ? "bg-destructive/20 text-destructive border border-destructive/30" : "text-muted-foreground hover:text-destructive hover:bg-destructive/10 border border-transparent")}>
                <Trash className="w-3.5 h-3.5" />
                {confirmClear ? "Click again to confirm" : "Clear all chats"}
              </button>
            )}
          </div>
        )}
      </div>

      {/* User profile */}
      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full flex-shrink-0 overflow-hidden bg-primary/20 flex items-center justify-center">
            {avatarUrl ? <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              : <span className="text-[11px] font-bold text-primary">{initials}</span>}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium text-foreground truncate">{displayName}</div>
            {displayEmail && <div className="text-[10px] text-muted-foreground truncate font-mono">{displayEmail}</div>}
          </div>
          <button onClick={() => signOut({ redirectUrl: basePath || "/" })} title="Sign out"
            className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex-shrink-0">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
