export const LANGUAGES = [
  { code: "English",   label: "English",    flag: "🇬🇧" },
  { code: "Hinglish",  label: "Hinglish",   flag: "🇮🇳" },
  { code: "Hindi",     label: "हिंदी",       flag: "🇮🇳" },
  { code: "Spanish",   label: "Español",    flag: "🇪🇸" },
  { code: "French",    label: "Français",   flag: "🇫🇷" },
  { code: "Arabic",    label: "العربية",    flag: "🇸🇦" },
  { code: "Bengali",   label: "বাংলা",      flag: "🇧🇩" },
  { code: "Tamil",     label: "தமிழ்",      flag: "🇮🇳" },
  { code: "Telugu",    label: "తెలుగు",     flag: "🇮🇳" },
  { code: "Gujarati",  label: "ગુજરાતી",    flag: "🇮🇳" },
  { code: "Marathi",   label: "मराठी",      flag: "🇮🇳" },
];
