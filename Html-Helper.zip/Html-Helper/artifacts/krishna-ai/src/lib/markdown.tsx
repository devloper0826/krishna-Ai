import React, { useState } from "react";
import { Copy, Check } from "lucide-react";

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group rounded-md overflow-hidden border border-zinc-700 my-3">
      <div className="flex items-center justify-between bg-zinc-800 px-4 py-1.5">
        <span className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider">{lang || "code"}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 text-[11px] font-mono text-zinc-400 hover:text-zinc-200 transition-colors"
        >
          {copied ? <><Check className="w-3 h-3 text-green-400" /><span className="text-green-400">Copied!</span></> : <><Copy className="w-3 h-3" />Copy</>}
        </button>
      </div>
      <pre className="bg-zinc-900 px-4 py-3 overflow-x-auto text-sm text-zinc-200 font-mono leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function renderInline(text: string): React.ReactNode[] {
  const result: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Bold **text**
    const boldMatch = remaining.match(/^(.*?)\*\*(.+?)\*\*/s);
    // Italic *text* (not **)
    const italicMatch = remaining.match(/^(.*?)(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/s);
    // Inline code `text`
    const codeMatch = remaining.match(/^(.*?)`([^`]+)`/s);

    const candidates: { idx: number; type: string; before: string; content: string; skip: number }[] = [];
    if (boldMatch) candidates.push({ idx: (boldMatch[1] ?? "").length, type: "bold", before: boldMatch[1] ?? "", content: boldMatch[2] ?? "", skip: boldMatch[0].length });
    if (italicMatch) candidates.push({ idx: (italicMatch[1] ?? "").length, type: "italic", before: italicMatch[1] ?? "", content: italicMatch[2] ?? "", skip: italicMatch[0].length });
    if (codeMatch) candidates.push({ idx: (codeMatch[1] ?? "").length, type: "code", before: codeMatch[1] ?? "", content: codeMatch[2] ?? "", skip: codeMatch[0].length });

    if (candidates.length === 0) {
      result.push(<span key={key++}>{remaining}</span>);
      break;
    }

    candidates.sort((a, b) => a.idx - b.idx);
    const best = candidates[0];
    if (best.before) result.push(<span key={key++}>{best.before}</span>);
    if (best.type === "bold") result.push(<strong key={key++} className="font-semibold text-foreground">{best.content}</strong>);
    else if (best.type === "italic") result.push(<em key={key++} className="italic">{best.content}</em>);
    else if (best.type === "code") result.push(<code key={key++} className="bg-zinc-800 text-amber-300 px-1.5 py-0.5 rounded text-[0.85em] font-mono">{best.content}</code>);
    remaining = remaining.slice(best.skip);
  }
  return result;
}

export function SimpleMarkdown({ content }: { content: string }) {
  if (!content) return null;

  const segments = content.split(/(```[\s\S]*?```)/g);

  const nodes: React.ReactNode[] = [];
  let key = 0;

  for (const seg of segments) {
    if (seg.startsWith("```") && seg.endsWith("```")) {
      const inner = seg.slice(3, -3);
      const newlineIdx = inner.indexOf("\n");
      const lang = newlineIdx !== -1 ? inner.slice(0, newlineIdx).trim() : "";
      const code = newlineIdx !== -1 ? inner.slice(newlineIdx + 1).trim() : inner.trim();
      nodes.push(<CodeBlock key={key++} lang={lang} code={code} />);
      continue;
    }

    const lines = seg.split("\n");
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];

      // Blank line
      if (!line.trim()) { nodes.push(<div key={key++} className="h-2" />); i++; continue; }

      // HR ---
      if (/^---+$/.test(line.trim())) { nodes.push(<hr key={key++} className="border-border my-3" />); i++; continue; }

      // Headings
      const h3 = line.match(/^###\s+(.*)/);
      const h2 = line.match(/^##\s+(.*)/);
      const h1 = line.match(/^#\s+(.*)/);
      if (h1) { nodes.push(<h1 key={key++} className="text-xl font-bold text-foreground mt-4 mb-2">{renderInline(h1[1] ?? "")}</h1>); i++; continue; }
      if (h2) { nodes.push(<h2 key={key++} className="text-lg font-semibold text-foreground mt-3 mb-1.5">{renderInline(h2[1] ?? "")}</h2>); i++; continue; }
      if (h3) { nodes.push(<h3 key={key++} className="text-base font-semibold text-foreground mt-2 mb-1">{renderInline(h3[1] ?? "")}</h3>); i++; continue; }

      // Blockquote
      if (line.startsWith("> ")) {
        nodes.push(
          <blockquote key={key++} className="border-l-2 border-primary/50 pl-3 text-muted-foreground italic my-2">
            {renderInline(line.slice(2))}
          </blockquote>
        );
        i++; continue;
      }

      // Unordered list — collect consecutive items
      if (/^[-*•]\s/.test(line)) {
        const items: string[] = [];
        while (i < lines.length && /^[-*•]\s/.test(lines[i])) {
          items.push(lines[i].replace(/^[-*•]\s/, ""));
          i++;
        }
        nodes.push(
          <ul key={key++} className="list-disc list-inside space-y-1 my-2 text-foreground/90">
            {items.map((it, idx) => <li key={idx} className="leading-relaxed">{renderInline(it)}</li>)}
          </ul>
        );
        continue;
      }

      // Ordered list
      if (/^\d+\.\s/.test(line)) {
        const items: string[] = [];
        while (i < lines.length && /^\d+\.\s/.test(lines[i])) {
          items.push(lines[i].replace(/^\d+\.\s/, ""));
          i++;
        }
        nodes.push(
          <ol key={key++} className="list-decimal list-inside space-y-1 my-2 text-foreground/90">
            {items.map((it, idx) => <li key={idx} className="leading-relaxed">{renderInline(it)}</li>)}
          </ol>
        );
        continue;
      }

      // Normal paragraph
      nodes.push(<p key={key++} className="leading-relaxed my-0.5">{renderInline(line)}</p>);
      i++;
    }
  }

  return <div className="space-y-0.5 text-[15px]">{nodes}</div>;
}
