export const MODELS = [
  { id: "gpt-4o-mini",   label: "GPT-4o mini",   desc: "Fast & Smart" },
  { id: "gpt-4o",        label: "GPT-4o",         desc: "Most Capable" },
  { id: "gpt-3.5-turbo", label: "GPT-3.5 Turbo",  desc: "Lightweight" },
];
