import { useState, useCallback, useRef, useEffect } from "react";

// Feminine-sounding voice name keywords (checked in priority order)
const FEMALE_VOICE_KEYWORDS = [
  "samantha", "victoria", "karen", "moira", "veena", "zira", "hazel",
  "aria", "jenny", "michelle", "sonia", "susan", "heather", "neerja",
  "google us english", "female", "woman",
];

function pickFemaleVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  const english = voices.filter((v) => v.lang.startsWith("en"));

  for (const kw of FEMALE_VOICE_KEYWORDS) {
    const match = english.find((v) => v.name.toLowerCase().includes(kw));
    if (match) return match;
  }
  // Pick any English voice
  return english[0] ?? voices[0] ?? null;
}

export interface VoiceHook {
  isListening: boolean;
  isSpeaking: boolean;
  isSupported: boolean;
  speak: (text: string, onEnd?: () => void) => void;
  stopSpeaking: () => void;
  startListening: (onResult: (text: string) => void, onError?: (err: string) => void) => void;
  stopListening: () => void;
}

export function useVoice(): VoiceHook {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const hasSynthesis = "speechSynthesis" in window;
    const hasRecognition = "SpeechRecognition" in window || "webkitSpeechRecognition" in window;
    setIsSupported(hasSynthesis && hasRecognition);

    if (hasSynthesis) {
      const loadVoices = () => { voiceRef.current = pickFemaleVoice(); };
      loadVoices();
      window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
      return () => window.speechSynthesis.removeEventListener("voiceschanged", loadVoices);
    }
  }, []);

  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();

    // Strip markdown for cleaner speech
    const clean = text
      .replace(/#{1,6}\s/g, "")
      .replace(/\*\*(.+?)\*\*/g, "$1")
      .replace(/\*(.+?)\*/g, "$1")
      .replace(/`{1,3}[^`]*`{1,3}/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/^\s*[-*+]\s/gm, "")
      .replace(/\n{2,}/g, ". ")
      .replace(/\n/g, " ")
      .trim()
      .slice(0, 500); // don't speak super long responses

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.pitch = 1.15;   // slightly higher = more feminine
    utterance.rate = 0.9;     // slightly slower = warmer, more intimate
    utterance.volume = 1;

    const voice = voiceRef.current ?? pickFemaleVoice();
    if (voice) utterance.voice = voice;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => { setIsSpeaking(false); onEnd?.(); };
    utterance.onerror = () => setIsSpeaking(false);

    // Chrome bug: synthesis stops after ~15s. Keep it alive.
    const keepAlive = setInterval(() => {
      if (!window.speechSynthesis.speaking) { clearInterval(keepAlive); return; }
      window.speechSynthesis.pause();
      window.speechSynthesis.resume();
    }, 10000);
    utterance.onend = () => { clearInterval(keepAlive); setIsSpeaking(false); onEnd?.(); };
    utterance.onerror = () => { clearInterval(keepAlive); setIsSpeaking(false); };

    window.speechSynthesis.speak(utterance);
  }, []);

  const stopSpeaking = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  const startListening = useCallback(
    (onResult: (text: string) => void, onError?: (err: string) => void) => {
      if (typeof window === "undefined") return;
      const SpeechRec =
        (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition })
          .SpeechRecognition ??
        (window as unknown as { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;

      if (!SpeechRec) { onError?.("Speech recognition not supported in this browser"); return; }

      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = "en-US";
      rec.maxAlternatives = 1;

      rec.onstart = () => setIsListening(true);
      rec.onresult = (e) => {
        const transcript = e.results[0]?.[0]?.transcript ?? "";
        if (transcript.trim()) onResult(transcript.trim());
      };
      rec.onerror = (e) => {
        setIsListening(false);
        onError?.(e.error);
      };
      rec.onend = () => setIsListening(false);

      recognitionRef.current = rec;
      rec.start();
    },
    []
  );

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  return { isListening, isSpeaking, isSupported, speak, stopSpeaking, startListening, stopListening };
}
