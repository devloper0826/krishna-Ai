import React, { useState, useRef, useEffect, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Cpu, Menu, ChevronDown, Download, Sun, Moon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Sidebar } from "@/components/chat/sidebar";
import { ChatInput } from "@/components/chat/chat-input";
import { MessageBubble } from "@/components/chat/message-bubble";
import { useVoice } from "@/lib/useVoice";
import { COMPANION_SYSTEM_PROMPT } from "@/lib/companion";
import {
  useCreateOpenaiConversation,
  useGetOpenaiConversation,
  getGetOpenaiConversationQueryKey,
  getListOpenaiConversationsQueryKey
} from "@workspace/api-client-react";

const QUICK_PROMPTS = [
  { emoji: "💡", text: "Explain a concept simply" },
  { emoji: "✍️", text: "Help me write something" },
  { emoji: "🐛", text: "Debug my code" },
  { emoji: "📚", text: "Teach me something new" },
  { emoji: "🌐", text: "Translate this for me" },
  { emoji: "🧠", text: "Brainstorm ideas with me" },
];

const COMPANION_QUICK_PROMPTS = [
  { emoji: "💕", text: "Tell me something sweet" },
  { emoji: "😊", text: "Make me smile today" },
  { emoji: "🌸", text: "Give me a compliment" },
  { emoji: "✨", text: "What's your vibe today?" },
  { emoji: "💬", text: "Let's just chat" },
  { emoji: "🎵", text: "Recommend a song for my mood" },
];

export default function ChatPage() {
  const [activeId, setActiveId] = useState<number | null>(null);
  const [tempUserMsg, setTempUserMsg] = useState<string>("");
  const [streamingMsg, setStreamingMsg] = useState<string>("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [language, setLanguage] = useState("English");
  const [model, setModel] = useState("gpt-4o-mini");
  const [temperature, setTemperature] = useState(0.7);
  const [systemPrompt, setSystemPrompt] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [companionMode, setCompanionMode] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">(() =>
    (localStorage.getItem("krishna-theme") as "dark" | "light") ?? "dark"
  );

  const voice = useVoice();
  const abortControllerRef = useRef<AbortController | null>(null);
  const lastUserMsgRef = useRef<string>("");
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const createConversation = useCreateOpenaiConversation();

  // Apply theme
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.classList.toggle("light", theme === "light");
    localStorage.setItem("krishna-theme", theme);
  }, [theme]);

  // When companion mode turns on, set creativity to 1.1 for more natural flow
  useEffect(() => {
    if (companionMode) setTemperature(1.1);
  }, [companionMode]);

  const { data: conversationData } = useGetOpenaiConversation(activeId!, {
    query: { enabled: !!activeId, queryKey: getGetOpenaiConversationQueryKey(activeId!) }
  });

  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
  };

  useEffect(() => { scrollToBottom(); }, [conversationData?.messages, tempUserMsg, streamingMsg]);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const onScroll = () => {
      setShowScrollBtn(container.scrollHeight - container.scrollTop - container.clientHeight > 200);
    };
    container.addEventListener("scroll", onScroll);
    return () => container.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); setActiveId(null); }
      if ((e.ctrlKey || e.metaKey) && e.key === "e") { e.preventDefault(); handleExport(); }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [conversationData]);

  // Effective system prompt: companion overrides custom
  const effectiveSystemPrompt = companionMode ? COMPANION_SYSTEM_PROMPT : systemPrompt;

  const streamMessage = useCallback(async (convId: number, content: string, firstMsg: boolean) => {
    setTempUserMsg(content);
    setIsStreaming(true);
    setStreamingMsg("");
    lastUserMsgRef.current = content;

    const controller = new AbortController();
    abortControllerRef.current = controller;

    let fullText = "";

    try {
      const response = await fetch(`/api/openai/conversations/${convId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content,
          language,
          model,
          temperature,
          systemPrompt: effectiveSystemPrompt,
        }),
        signal: controller.signal,
      });

      if (!response.body) throw new Error("No response body");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value, { stream: true });
        for (const line of text.split("\n")) {
          if (!line.startsWith("data: ")) continue;
          const dataStr = line.slice(6);
          if (!dataStr) continue;
          try {
            const data = JSON.parse(dataStr);
            if (data.content) {
              fullText += data.content;
              setStreamingMsg(fullText);
              scrollToBottom();
            }
          } catch { /* partial */ }
        }
      }

      // Auto-generate title after first message
      if (firstMsg) {
        fetch(`/api/openai/conversations/${convId}/generate-title`, { method: "POST" })
          .then(() => queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() }))
          .catch(() => {});
      }

      // Auto-speak if voice mode is on
      if (voiceMode && fullText.trim()) {
        voice.speak(fullText);
      }

    } catch (err: unknown) {
      if (!(err instanceof Error && err.name === "AbortError")) console.error("Streaming error", err);
    } finally {
      setIsStreaming(false);
      setTempUserMsg("");
      setStreamingMsg("");
      abortControllerRef.current = null;
      queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(convId) });
      queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    }
  }, [language, model, temperature, effectiveSystemPrompt, queryClient, voiceMode, voice]);

  const handleSend = async (content: string) => {
    if (isStreaming) return;
    // Stop speaking if something is playing
    if (voice.isSpeaking) voice.stopSpeaking();

    let convId = activeId;
    const isFirst = !convId;
    if (!convId) {
      try {
        const newConv = await createConversation.mutateAsync({ data: { title: content.slice(0, 50) || "New Chat" } });
        convId = newConv.id;
        setActiveId(convId);
        queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
      } catch (err) { console.error("Failed to create conversation", err); return; }
    }
    await streamMessage(convId, content, isFirst);
  };

  const handleStop = () => {
    abortControllerRef.current?.abort();
    voice.stopSpeaking();
  };

  const handleMicClick = () => {
    if (voice.isListening) {
      voice.stopListening();
    } else {
      voice.stopSpeaking();
      voice.startListening(
        (transcript) => { handleSend(transcript); },
        (err) => { console.warn("Voice input error:", err); }
      );
    }
  };

  const handleGenerateImage = async (prompt: string) => {
    if (isStreaming || isGeneratingImage) return;
    voice.stopSpeaking();
    let convId = activeId;
    const isFirst = !convId;
    if (!convId) {
      try {
        const newConv = await createConversation.mutateAsync({ data: { title: `🎨 ${prompt.slice(0, 40)}` } });
        convId = newConv.id;
        setActiveId(convId);
        queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
      } catch (err) { console.error("Failed to create conversation", err); return; }
    }
    setIsGeneratingImage(true);
    try {
      const resp = await fetch(`/api/openai/conversations/${convId}/generate-image`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "Unknown error" }));
        console.error("Image generation failed:", err);
      }
      if (isFirst) {
        fetch(`/api/openai/conversations/${convId}/generate-title`, { method: "POST" })
          .then(() => queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() }))
          .catch(() => {});
      }
    } finally {
      setIsGeneratingImage(false);
      queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(convId) });
      queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    }
  };

  const handleRegenerate = async () => {
    if (!activeId || isStreaming || !lastUserMsgRef.current) return;
    voice.stopSpeaking();
    await streamMessage(activeId, lastUserMsgRef.current, false);
  };

  const handleExport = () => {
    if (!conversationData || !conversationData.messages?.length) return;
    const lines = [
      `# ${conversationData.title}`,
      `*Exported from KrishnaAI · ${new Date().toLocaleDateString()}*`,
      `*Model: ${model} | Language: ${language}*`,
      "",
      ...conversationData.messages.map((m) =>
        m.role === "user" ? `**You:** ${m.content}` : `**KrishnaAI:** ${m.content}`
      ),
    ];
    const blob = new Blob([lines.join("\n\n")], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(conversationData.title ?? "chat").replace(/[^a-z0-9]/gi, "_")}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const messages = conversationData?.messages || [];
  const lastAssistantIdx = [...messages].reverse().findIndex((m) => m.role === "assistant");
  const lastAssistantId = lastAssistantIdx >= 0 ? messages[messages.length - 1 - lastAssistantIdx]?.id : null;

  useEffect(() => {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (lastUser) lastUserMsgRef.current = lastUser.content;
  }, [messages]);

  const quickPrompts = companionMode ? COMPANION_QUICK_PROMPTS : QUICK_PROMPTS;

  // Companion header glow color
  const glowClass = companionMode
    ? "bg-pink-500/8"
    : "bg-primary/5";

  return (
    <div className={`flex h-screen w-full bg-background text-foreground overflow-hidden font-sans selection:bg-primary/30 transition-colors duration-500`}>
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-20 md:hidden" onClick={() => setSidebarOpen(false)} />}

      <div className={`fixed md:relative inset-y-0 left-0 z-30 transform transition-transform duration-300 md:transform-none ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`}>
        <Sidebar
          activeId={activeId}
          onSelect={(id) => { setActiveId(id); setSidebarOpen(false); }}
          language={language} onLanguageChange={setLanguage}
          model={model} onModelChange={setModel}
          temperature={temperature} onTemperatureChange={setTemperature}
          systemPrompt={systemPrompt} onSystemPromptChange={setSystemPrompt}
          companionMode={companionMode} onCompanionModeChange={setCompanionMode}
          voiceMode={voiceMode} onVoiceModeChange={setVoiceMode}
          onClose={() => setSidebarOpen(false)}
        />
      </div>

      <div className="flex-1 flex flex-col relative min-w-0">
        {/* Top bar */}
        <div className={`flex items-center gap-2 px-4 py-2.5 border-b border-border backdrop-blur z-10 transition-colors duration-500 ${companionMode ? "bg-gradient-to-r from-background via-pink-950/20 to-background" : "bg-background/90"}`}>
          <button onClick={() => setSidebarOpen(true)} className="md:hidden p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            <Menu className="w-5 h-5" />
          </button>
          {companionMode ? (
            <span className="text-sm font-bold md:hidden bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">Priya 💋</span>
          ) : (
            <>
              <img src={`${import.meta.env.BASE_URL}favicon.png`} alt="KrishnaAI" className="w-6 h-6 rounded-full object-cover md:hidden" />
              <span className="text-sm font-bold md:hidden">KrishnaAI</span>
            </>
          )}
          <div className="flex-1" />

          {/* Model pill */}
          <span className="hidden md:flex items-center gap-1.5 text-[11px] font-mono text-muted-foreground bg-muted/50 border border-border px-2.5 py-1 rounded-full">
            <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${companionMode ? "bg-pink-400" : "bg-primary"}`} />
            {companionMode ? "Priya 💋" : model}
          </span>

          {/* Export */}
          {activeId && messages.length > 0 && (
            <button onClick={handleExport} title="Export (Ctrl+E)"
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground border border-border hover:border-primary/40 px-2.5 py-1 rounded-full transition-colors font-mono">
              <Download className="w-3.5 h-3.5" />Export
            </button>
          )}

          {/* Theme toggle */}
          <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title="Toggle theme"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

        {/* Background glow */}
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] ${glowClass} rounded-full blur-[120px] pointer-events-none transition-colors duration-700`} />

        {/* Messages */}
        <div ref={scrollContainerRef} className="flex-1 overflow-y-auto p-4 sm:p-8 scroll-smooth z-10">
          <div className="max-w-3xl mx-auto space-y-8 pb-10">
            {!activeId && !tempUserMsg ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                className="flex flex-col items-center justify-center min-h-[50vh] space-y-8 text-center">
                <div className="space-y-4">
                  <div className="relative mx-auto w-20 h-20">
                    <div className={`absolute inset-0 blur-xl rounded-full ${companionMode ? "bg-pink-500/25" : "bg-primary/20"}`} />
                    {companionMode ? (
                      <div className="relative z-10 w-20 h-20 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(236,72,153,0.35)]">
                        💋
                      </div>
                    ) : (
                      <img src={`${import.meta.env.BASE_URL}favicon.png`} alt="KrishnaAI"
                        className="relative z-10 w-20 h-20 rounded-full object-cover shadow-[0_0_30px_rgba(212,175,55,0.3)]" />
                    )}
                  </div>
                  <div>
                    {companionMode ? (
                      <>
                        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">
                          Hey, I'm Priya 💋
                        </h1>
                        <p className="text-muted-foreground text-sm mt-1">Your warm, witty AI companion ✨</p>
                      </>
                    ) : (
                      <>
                        <h1 className="text-3xl font-bold tracking-tight text-foreground">KrishnaAI</h1>
                        <p className="text-muted-foreground font-mono text-sm mt-1">Learn Smart. Think Big.</p>
                      </>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 w-full max-w-lg">
                  {quickPrompts.map((p) => (
                    <button key={p.text} onClick={() => handleSend(p.text)}
                      className={`flex items-center gap-2 px-3 py-2.5 bg-card border rounded-xl text-sm text-left transition-colors group ${companionMode ? "border-pink-500/20 hover:border-pink-500/50 hover:bg-pink-500/5" : "border-border hover:border-primary/40 hover:bg-card/80"}`}>
                      <span className="text-base flex-shrink-0">{p.emoji}</span>
                      <span className="text-muted-foreground group-hover:text-foreground transition-colors text-xs leading-tight">{p.text}</span>
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground font-mono opacity-50">
                  Press <kbd className="px-1 py-0.5 border border-border rounded text-[10px]">Ctrl+K</kbd> for new chat
                </p>
              </motion.div>
            ) : (
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <MessageBubble key={msg.id} role={msg.role as "user" | "assistant"} content={msg.content}
                    language={language}
                    onRegenerate={msg.id === lastAssistantId && !isStreaming ? handleRegenerate : undefined}
                    companionMode={companionMode}
                    onSpeak={voice.isSupported ? () => voice.speak(msg.content) : undefined}
                  />
                ))}
                {tempUserMsg && <MessageBubble role="user" content={tempUserMsg} />}
                {(isStreaming || streamingMsg) && (
                  <MessageBubble role="assistant" content={streamingMsg} isStreaming={isStreaming} language={language} companionMode={companionMode} />
                )}
                {isGeneratingImage && (
                  <MessageBubble role="assistant" content="" isGeneratingImage={true} />
                )}
              </AnimatePresence>
            )}
            <div ref={messagesEndRef} className="h-4" />
          </div>
        </div>

        {/* Scroll to bottom */}
        <AnimatePresence>
          {showScrollBtn && (
            <motion.button initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
              onClick={() => scrollToBottom()}
              className="absolute bottom-28 right-6 z-20 p-2 rounded-full bg-card border border-border shadow-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors">
              <ChevronDown className="w-5 h-5" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Input */}
        <div className="p-4 bg-gradient-to-t from-background via-background to-transparent pt-12 z-20">
          <ChatInput
            onSend={handleSend}
            onSendImage={handleGenerateImage}
            onStop={handleStop}
            disabled={isStreaming || isGeneratingImage}
            isListening={voice.isListening}
            isSpeaking={voice.isSpeaking}
            voiceMode={voiceMode}
            onToggleVoice={() => {
              if (voice.isSpeaking) voice.stopSpeaking();
              setVoiceMode((v) => !v);
            }}
            onMicClick={handleMicClick}
            companionMode={companionMode}
          />
          <div className="text-center mt-3">
            <span className="text-[11px] text-muted-foreground font-mono uppercase tracking-widest opacity-60">
              {companionMode ? "Priya is here for you ✨" : "KrishnaAI can make mistakes. Consider verifying."}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
